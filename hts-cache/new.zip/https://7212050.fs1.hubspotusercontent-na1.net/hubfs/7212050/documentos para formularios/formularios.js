if (typeof jQuery == 'undefined') {
    var script = document.createElement('script');
    script.src = 'https://code.jquery.com/jquery-3.6.0.min.js';
    script.type = 'text/javascript';
    document.getElementsByTagName('head')[0].appendChild(script);
}
var linkStyle = document.createElement('link');
linkStyle.rel = "stylesheet";
linkStyle.type = "text/css";
linkStyle.href = "https://7212050.fs1.hubspotusercontent-na1.net/hubfs/7212050/documentos%20para%20formularios/forms-style.css";
document.getElementsByTagName('head')[0].appendChild(linkStyle);



let ideForm = '';
function getForm(formide, urlRedirect) {
    hbspt.forms.create({
        region: "na1",
        portalId: "7212050",
        formId: formide,
        locale: 'es',
        translations: {
            es: {
                required: "Este campo es requerido",
                invalidEmailFormat: "Ingresa un correo electrónico válido (ejemplo@ejemplo.com)",
                invalidNumber: "Solo se permiten números en este campo",
                invalidDate: "Ingresa un formato de fecha dd/mm/aaaa",
                phoneInvalidCharacters: "Solo se permiten números en este campo"
            }
        },
        onFormReady: function ($form) {
            //Tag manager solutions
            jQuery("#" + $form[0].id).find(".hs-button.primary").addClass("enviar-principal sin-envio");
            //End tag manager 

            function setSelectors(text_specific, generalOption, specificOption, url) {
                let dropdown_general = jQuery('select[name="' + generalOption + '"]');
                let dropdown_specific = jQuery('select[name="' + specificOption + '"]');
                dropdown_specific.empty();
                dropdown_specific.append('<option selected="true" disabled> Selecciona' + text_specific + ' </option>');
                dropdown_specific.prop('selectedIndex', 0);
                try {
                    dropdown_general.off('change');
                } catch (e) { console.error(e); }
                let changeFunction = function (e) {
                    let dropdown_general = jQuery('select[name="' + generalOption + '"]');
                    let dropdown_specific = jQuery('select[name="' + specificOption + '"]');
                    dropdown_specific.empty();
                    dropdown_specific.append('<option selected="true" disabled> Selecciona una opción </option>');
                    dropdown_specific.prop('selectedIndex', 0);

                    const selected_general = dropdown_general.val() || "";
                    $.getJSON(url, function (data) {
                        const filtered = data.filter(opcion => opcion.key.toUpperCase() == selected_general.toUpperCase());

                        $.each(filtered, function (key, entry) {
                            dropdown_specific.append(`<option value="${entry.value}">${entry.value}</option>`);
                        });
                    });
                };
                dropdown_general.on("change", changeFunction);
                changeFunction();
            }
            function setDefaultSelectors() {
                setSelectors(' un departamento', 'departamento_de_nacimiento', 'ciudad_de_nacimiento', 'https://fs.hubspotusercontent00.net/hubfs/7212050/documentos%20para%20formularios/ciudades.json');
                setSelectors(' una unidad de servicio', 'unidad_de_servicio_formulario', 'linea_de_negocio', 'https://fs.hubspotusercontent00.net/hubfs/7212050/unidad_de_servicio.json');
                setSelectors(' un departamento', 'state', 'ciudad_de_residencia', 'https://fs.hubspotusercontent00.net/hubfs/7212050/documentos%20para%20formularios/ciudades.json');
                setSelectors(' un departamento', 'departamento_de_trabajo', 'ciudad_de_trabajo', 'https://fs.hubspotusercontent00.net/hubfs/7212050/documentos%20para%20formularios/ciudades.json');
                setSelectors(' un departamento', 'departamento_de_expedicion_de_documento', 'ciudad_de_expedicion_de_documento', 'https://fs.hubspotusercontent00.net/hubfs/7212050/documentos%20para%20formularios/ciudades.json');
            }
            setDefaultSelectors();
            //Submit section

            jQuery("#" + $form[0].id).find("[type='submit'].hs-button").click(function (event) {

                if (!(checkEmptyFields() == 0 && validateForm() == 0 && jQuery("#" + $form[0].id + " input:invalid").length <= 0)) {
                    event.preventDefault();
                }
            });

            //End submit section

            //Validate on input
            function validateInput(field) {
                let default_validations = getDefaultValidations();
                default_validations.forEach(function (el) {
                    if ($form[0].querySelector(el.selector) == field) {
                        getError(field, el.tipo, el.numero);
                    };
                });
                if (field.classList.contains(".hs-email")) {
                    validateEmailManual();
                }
            }
            function asignarValidaciones() {
                $form[0].querySelectorAll(".hs-form-field").forEach(function (elem) {
                    let input = elem.querySelector("input");
                    if (input) {
                        input.addEventListener("input", function () {
                            validateInput(elem);
                            checkOneEmptyField(elem);
                        });
                        input.addEventListener("blur", function (e) {
                            setTimeout(() => {
                                checkOneEmptyField(elem);
                            }, 5);
                            validateInput(elem);
                        });
                    }
                });
            }
            asignarValidaciones();
            //End Validate on input

            (function () {
                const idDoc = $form[0].querySelector(".hs_tipo_de_documento.hs-form-field, .hs_tipo_de_documento_de_identidad.hs-form-field");
                if (idDoc) {
                    const docNumSelector = ".hs_numero_de_documento.hs-form-field,.hs_numero_de_documento_de_identidad.hs-form-field";
                    idDoc.querySelector("select").addEventListener("change", function () {
                        let fieldNum = $form[0].querySelector(docNumSelector);
                        let inputFieldNum = fieldNum.querySelector("input");
                        fieldNum.querySelectorAll("ul.hs-error-msgs").forEach(function (el) { el.innerHTML = '' });
                        inputFieldNum.setCustomValidity("");
                        inputFieldNum.classList.remove("invalid");
                        validateInput(fieldNum);
                    });
                }
            }());

            function getDefaultValidations() {
                let default_validations = [
                    { selector: ".hs_primer_nombre.hs-form-field", tipo: "solo_letras", numero: 0 },
                    { selector: ".hs_primer_nombre.hs-form-field", tipo: "no_especiales", numero: 0 },
                    { selector: ".hs_firstname.hs-form-field", tipo: "solo_letras", numero: 0 },
                    { selector: ".hs_firstname.hs-form-field", tipo: "no_especiales", numero: 0 },
                    { selector: ".hs_segundo_nombre.hs-form-field", tipo: "solo_letras", numero: 0 },
                    { selector: ".hs_segundo_nombre.hs-form-field", tipo: "no_especiales", numero: 0 },
                    { selector: ".hs_lastname.hs-form-field", tipo: "solo_letras", numero: 0 },
                    { selector: ".hs_lastname.hs-form-field", tipo: "no_especiales", numero: 0 },
                    { selector: ".hs_primer_apellido.hs-form-field", tipo: "solo_letras", numero: 0 },
                    { selector: ".hs_primer_apellido.hs-form-field", tipo: "no_especiales", numero: 0 },
                    { selector: ".hs_segundo_apellido.hs-form-field", tipo: "solo_letras", numero: 0 },
                    { selector: ".hs_segundo_apellido.hs-form-field", tipo: "no_especiales", numero: 0 },
                    { selector: ".hs_mobilephone.hs-form-field", tipo: "start_num", numero: 3 },
                    { selector: ".hs_mobilephone.hs-form-field", tipo: "exact_dig", numero: 10 },
                    { selector: ".hs_mobilephone.hs-form-field", tipo: "solo_num", numero: 0 },
                    { selector: ".hs_phone.hs-form-field", tipo: "start_num", numero: 60 },
                    { selector: ".hs_phone.hs-form-field", tipo: "exact_dig", numero: 10 },
                    { selector: ".hs_phone.hs-form-field", tipo: "solo_num", numero: 0 },
                    { selector: ".hs_telefono_oficina.hs-form-field", tipo: "start_num", numero: 60 },
                    { selector: ".hs_telefono_oficina.hs-form-field", tipo: "exact_dig", numero: 10 },
                    { selector: ".hs_telefono_oficina.hs-form-field", tipo: "solo_num", numero: 0 },
                    { selector: ".hs_extension_oficina.hs-form-field", tipo: "solo_num", numero: 0 },
                    { selector: ".hs_extension_oficina.hs-form-field", tipo: "max_dig", numero: 7 },
                    { selector: ".legal-consent-container .hs-form-field", tipo: "terms", numero: 0 }
                ];
                const idDoc = $form[0].querySelector(".hs_tipo_de_documento.hs-form-field, .hs_tipo_de_documento_de_identidad.hs-form-field");
                if (idDoc) {
                    const idDocValue = idDoc.querySelector("select.hs-input").value.toLowerCase();
                    const docNumSelector = ".hs_numero_de_documento.hs-form-field,.hs_numero_de_documento_de_identidad.hs-form-field";
                    default_validations.push({ selector: docNumSelector, tipo: "no_repetidos", numero: 0 });
                    switch (idDocValue) {
                        case 'carnet diplomatica':
                            default_validations.push({ selector: docNumSelector, tipo: "no_especiales", numero: 0 });
                            default_validations.push({ selector: docNumSelector, tipo: "max_dig", numero: 15 }); break;
                        case 'cédula de extranjería':
                            default_validations.push({ selector: docNumSelector, tipo: "exact_dig", numero: 7 });
                            default_validations.push({ selector: docNumSelector, tipo: "solo_num", numero: 0 }); break;
                        case 'cédula de ciudadanía':
                            default_validations.push({ selector: docNumSelector, tipo: "solo_num", numero: 0 });
                            default_validations.push({ selector: docNumSelector, tipo: "min_dig", numero: 3 });
                            default_validations.push({ selector: docNumSelector, tipo: "max_dig", numero: 10 }); break;
                        case 'nit':
                            default_validations.push({ selector: docNumSelector, tipo: "solo_num", numero: 0 });
                            default_validations.push({ selector: docNumSelector, tipo: "exact_dig", numero: 10 }); break;
                        case 'nuip':
                            default_validations.push({ selector: docNumSelector, tipo: "solo_num", numero: 0 });
                            default_validations.push({ selector: docNumSelector, tipo: "exact_dig", numero: 10 }); break;
                        case 'pasaporte':
                            default_validations.push({ selector: docNumSelector, tipo: "min_dig", numero: 3 });
                            default_validations.push({ selector: docNumSelector, tipo: "max_dig", numero: 17 });
                            default_validations.push({ selector: docNumSelector, tipo: "no_especiales", numero: 0 }); break;
                        case 'permiso especial de permanencia':
                            default_validations.push({ selector: docNumSelector, tipo: "min_dig", numero: 14 });
                            default_validations.push({ selector: docNumSelector, tipo: "max_dig", numero: 15 });
                            default_validations.push({ selector: docNumSelector, tipo: "solo_num", numero: 0 }); break;
                        case 'registro civil':
                            default_validations.push({ selector: docNumSelector, tipo: "no_especiales", numero: 0 });
                            default_validations.push({ selector: docNumSelector, tipo: "min_dig", numero: 10 });
                            default_validations.push({ selector: docNumSelector, tipo: "max_dig", numero: 11 }); break;
                        case 'permiso proteccion temporal':
                            default_validations.push({ selector: docNumSelector, tipo: "solo_num", numero: 0 });
                            default_validations.push({ selector: docNumSelector, tipo: "min_dig", numero: 7 });
                            default_validations.push({ selector: docNumSelector, tipo: "max_dig", numero: 15 }); break;
                        case 'rut':
                            default_validations.push({ selector: docNumSelector, tipo: "solo_num", numero: 0 });
                            default_validations.push({ selector: docNumSelector, tipo: "max_dig", numero: 10 }); break;
                        case 'tarjeta de identidad':
                            default_validations.push({ selector: docNumSelector, tipo: "solo_num", numero: 0 });
                            default_validations.push({ selector: docNumSelector, tipo: "min_dig", numero: 10 });
                            default_validations.push({ selector: docNumSelector, tipo: "max_dig", numero: 11 }); break;
                        default: break;
                    }
                }
                return default_validations;
            }
            //Custom validation    
            function validateForm() {

                $form[0].querySelectorAll(".hs-form-field input").forEach(function (elem) {
                    elem.classList.remove("invalid");
                    elem.setCustomValidity("");
                    let errorsList = elem.closest(".hs-form-field").querySelector("ul.custom_errors");
                    errorsList ? errorsList.remove() : "";
                });

                let default_validations = getDefaultValidations();
                let response = 0;

                default_validations.forEach(function (elem) {
                    response += defaultValidation(elem.selector, elem.tipo, elem.numero);
                });
                response += validateEmailManual();

                return response;
            }

            function validateEmailManual() {
                let emailfield = $form[0].querySelector(".hs-email.hs-form-field");
                if (emailfield) {
                    return getError(emailfield, 'email', 0);
                }
                return 0;
            }

            function defaultValidation(selector, tipo_validacion, numero_validacion) {
                let response = 0;
                const field = $form[0].querySelector(selector);
                if (field) {
                    response = getError(field, tipo_validacion, numero_validacion);
                }
                return response;
            }

            function getError(field, tipo_validacion, numero_validacion) {

                let response = 0;
                let errormsg = "";

                const valorinput = field.querySelector("input").value;
                if (valorinput.length > 0) {
                    switch (tipo_validacion) {
                        case 'solo_letras':
                            errormsg = validateOnlyLetters(valorinput); break;
                        case 'solo_num':
                            errormsg = validateOnlyNumbers(valorinput); break;
                        case 'no_especiales':
                            errormsg = validateNotSpecialChar(valorinput); break;
                        case 'min_dig':
                            errormsg = validateMinLength(valorinput, numero_validacion); break;
                        case 'max_dig':
                            errormsg = validateMaxLength(valorinput, numero_validacion); break;
                        case 'exact_dig':
                            errormsg = validateExactLength(valorinput, numero_validacion); break;
                        case 'start_num':
                            errormsg = validateStartsWith(valorinput, numero_validacion); break;
                        case 'no_repetidos':
                            errormsg = validateNoRepeated(valorinput); break;
                        case 'email':
                            errormsg = validateEmail(valorinput, numero_validacion); break;
                        case 'terms':
                            return checkTerms();
                        default: break;
                    }
                } else {
                    errormsg = "ok";
                }

                if (errormsg != "ok") {
                    setTimeout(() => {
                        let newField = $form[0].getElementsByClassName(field.className)[0];
                        let errorsList = newField.querySelector("ul.hs-error-msgs");
                        if (!errorsList) {
                            errorsList = document.createElement("ul");
                            errorsList.classList.add("custom_errors", "no-list", "hs-error-msgs", "inputs-list");
                            errorsList.style.display = "block";
                            errorsList.role = "alert";
                            errorsList.innerHTML = `<li><label class="hs-error-msg">${errormsg}</label></li>`;

                            newField.appendChild(errorsList);
                        } else {
                            if (!errorsList.innerText.includes(errormsg)) {
                                errorsList.innerHTML = errorsList.innerHTML + `<li><label class="hs-error-msg">${errormsg}</label></li>`;
                            }
                        }
                        let fieldInput = newField.querySelector("input");
                        fieldInput.setCustomValidity("Invalid error field.");
                        fieldInput.classList.add("invalid");
                        fieldInput.addEventListener("input", function (e) {
                            fieldInput.classList.remove("invalid");
                            fieldInput.setCustomValidity("");
                            let errorsList = newField.querySelector("ul.hs-error-msgs");
                            errorsList ? errorsList.remove() : "";
                        });

                    }, 5);
                    response = 1;
                }
                return response;
            }

            function validateOnlyLetters(fieldValue) {
                return fieldValue.match(/^[A-Za-z]*$/) ? "ok" : "Solo se permiten letras en este campo";
            }
            function validateOnlyNumbers(fieldValue) {
                return fieldValue.match(/^(\s*|\d+)$/) ? "ok" : "Solo se permiten números en este campo";
            }
            function validateMinLength(fieldValue, min) {
                return fieldValue.length >= min ? "ok" : "Ingresa como mínimo " + min + " digitos";
            }
            function validateMaxLength(fieldValue, max) {
                return fieldValue.length <= max ? "ok" : "Ingresa como máximo " + max + " digitos";
            }
            function validateExactLength(fieldValue, num) {
                return fieldValue.length == num ? "ok" : "Solo puedes ingresar " + num + " digitos en este campo";
            }
            function validateNotSpecialChar(fieldValue) {
                return fieldValue.match(/^[a-zA-Z0-9]*$/) ? "ok" : `No se permiten caracteres especiales (+*-/$%&#"!)(=?¡¿°)`;
            }
            function validateStartsWith(fieldValue, num) {
                return fieldValue.substr(0, num.toString().length) == num.toString() ? "ok" : 'Debe iniciar siempre con el número ' + num;
            }
            function validateEmail(fieldValue) {
                return fieldValue.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/) ? "ok" : 'Ingresa un correo electrónico válido (ejemplo@ejemplo.com)';
            }
            function validateNoRepeated(fieldValue) {
                if (fieldValue.length > 3) {
                    let num = fieldValue[1];
                    for (var i = 2; i < fieldValue.length; i++) {
                        if (fieldValue[i] != num) return "ok";
                    }
                    return "El valor ingresado es inválido";
                }
                return "ok";
            }
            //end custom validation

            //Error messages section 
            function checkTerms() {
                if ($form[0].querySelector(".legal-consent-container input").checked == false) {
                    setTimeout(function () {
                        const errormsg = "Debes aceptar los términos y condiciones para continuar";
                        const msg = jQuery(".legal-consent-container .hs-error-msg").html();
                        if (msg) {
                            if (!msg.includes(errormsg)) {
                                jQuery(".legal-consent-container .hs-error-msg").html(errormsg);
                            }
                        } else {
                            const errorsList = document.createElement("ul");
                            errorsList.classList.add("custom_errors", "no-list", "hs-error-msgs", "inputs-list");
                            errorsList.style.display = "block";
                            errorsList.role = "alert";
                            errorsList.innerHTML = `<li><label class="hs-error-msg">${errormsg}</label></li>`;

                            const field = $form[0].querySelector(".legal-consent-container .hs-form-field");
                            field.appendChild(errorsList);

                            const fieldInput = field.querySelector("input");
                            fieldInput.setCustomValidity("Invalid terms field.");
                            fieldInput.classList.add("invalid");
                            fieldInput.addEventListener("change", function (e) {
                                clearCustomError(fieldInput, field, "ul.hs-error-msgs");
                                checkTerms();
                            });
                        }
                    }, 5);
                    return 1;
                }
                return 0;
            }
            jQuery(".legal-consent-container input").change(function () {
                checkTerms();
            });


            function clearCustomError(item, parent, selector) {
                item.classList.remove("invalid");
                item.setCustomValidity("");
                let checkErrorsList = parent.querySelector(selector);
                checkErrorsList ? checkErrorsList.remove() : "";
            }
            function checkOneEmptyField(field) {
                let response = 0;
                const requiredspan = field.querySelector(".hs-form-required");
                const input = field.querySelector("input");
                const isEmpty = input ? input.value.length == 0 : false;
                if (requiredspan && isEmpty) {
                    response++;
                    const parentelem = field;
                    const fieldname = parentelem.querySelector("label span").innerHTML;
                    const errormsg = "El campo " + fieldname + " es obligatorio";
                    let errorsList = parentelem.querySelector("ul.hs-error-msgs");
                    if (!errorsList) {
                        errorsList = document.createElement("ul");
                        errorsList.classList.add("custom_errors", "no-list", "hs-error-msgs", "inputs-list");
                        errorsList.style.display = "block";
                        errorsList.role = "alert";
                        errorsList.innerHTML = `<li><label class="hs-error-msg">${errormsg}</label></li>`;
                        parentelem.appendChild(errorsList);
                    } else {
                        let errorAdded = false;
                        errorsList.querySelectorAll("li").forEach(function (elem, i) {
                            if (elem.innerHTML.includes("Este campo es requerido")) {
                                elem.innerHTML = `<label class="hs-error-msg">${errormsg}</label>`;
                                errorAdded = true;
                            }
                        });
                        if (!errorAdded) {
                            const isEmpty = input ? input.value.length == 0 : false;
                            if (isEmpty && !errorsList.innerText.includes(errormsg)
                                && !errorsList.innerText.includes("términos y condiciones")) {
                                errorsList.innerHTML = errorsList.innerHTML + `<li><label class="hs-error-msg">${errormsg}</label></li>`;
                            }
                        }
                    }

                    let fieldInput = parentelem.querySelector("input");
                    let fieldSelect = parentelem.querySelector("select");
                    if (fieldInput) {
                        fieldInput.classList.add("invalid");
                        fieldInput.setCustomValidity("Invalid empty field.");

                        fieldInput.addEventListener("change", function (e) {
                            clearCustomError(fieldInput, parentelem, "ul.custom_errors");
                        });

                    }
                    if (fieldSelect) {
                        fieldSelect.classList.add("invalid");
                        fieldSelect.setCustomValidity("Invalid empty field.");
                        fieldSelect.addEventListener("change", function (e) {
                            clearCustomError(fieldSelect, parentelem, "ul.custom_errors");
                        });
                    }
                }
                return response;
            }
            function checkEmptyFields() {
                let response = 0;
                jQuery("#" + $form[0].id).find(".hs-form-field:visible").each(function (i, field) {
                    response += checkOneEmptyField(field);
                });
                return response;
            }

            //End error messages section

            //Add optional label
            function addOptionaltext() {
                jQuery(".hs-form-field").each(function () {
                    let req = jQuery(this).find(".hs-form-required");
                    if (req.length > 0) {
                        req.html("");
                    } else {
                        let optionaltxt = jQuery(this).find(".optional-span");
                        if (optionaltxt.length == 0) {
                            jQuery(this).find("label").append("<span class='optional-span'> (Opcional)</span>");
                        }
                    }
                });
            }
            addOptionaltext();
            //End add optional label
            // Observer de campos dinamicos
            var targets = $form[0].querySelectorAll('.hs-dependent-field');
            targets.forEach(function (target) {
                var observer = new MutationObserver(function (mutations) {
                    mutations.forEach(function (mutation) {
                        setTimeout(function () {
                            setDefaultSelectors();
                            asignarValidaciones();
                            addOptionaltext();
                        }, 5);

                    });
                });

                var config = { attributes: true, childList: true, characterData: true };
                observer.observe(target, config);
            });
            //end observer de campos


            //File legend
            jQuery(".hs-archivo legend").appendTo(jQuery(".hs-archivo .input"));
            //End file legend

            ideForm = formide;
            const event = new Event('formBuild');
            document.dispatchEvent(event);
        },
        onFormSubmitted: function () {

            // const forminfo = document.getElementsByClassName("form-info")[0];
            // if (forminfo) { forminfo.style.display = "none"; }
            // jQuery(".alert-exito").show();

            // setTimeout(function () {
            //     jQuery(".alert-exito").fadeTo("slow", 0);
            // }, 3000);
            // setTimeout(function () {
            //     jQuery(".alert-exito").hide();
            // }, 4000);
            if (urlRedirect && urlRedirect != undefined) {
                window.location.href = urlRedirect;
            }
        }
    });

    window.onload = function () {
        jQuery(function () {
            jQuery("input[type='file']").change(function () {
                var val = jQuery(this).val().toLowerCase(),
                    regex = new RegExp("(.*?)\.(pdf|jpg|jpeg|png)$");

                if (!(regex.test(val))) {
                    jQuery(this).val('');
                    jQuery(this).css("border-color", " #D32F2F");
                } else {
                    jQuery(this).css("border-color", "#cbd6e2");
                }
            });
        });
    };
    window.onload = function () {

        jQuery(".closealert").click(function () {
            jQuery(".alert-exito").hide();
        });

    }

    //Datepicker
    function changeDays() {
        jQuery(".pika-table thead th:nth-child(1)").html("S");
        jQuery(".pika-table thead th:nth-child(2)").html("M");
        jQuery(".pika-table thead th:nth-child(3)").html("T");
        jQuery(".pika-table thead th:nth-child(4)").html("W");
        jQuery(".pika-table thead th:nth-child(5)").html("T");
        jQuery(".pika-table thead th:nth-child(6)").html("F");
        jQuery(".pika-table thead th:nth-child(7)").html("S");
    }
    function changeDaysEvents() {
        changeDays();
        jQuery(".pika-next").mousedown(function () {
            setTimeout(function () {
                changeDaysEvents();
            }, 1)
        });
        jQuery(".pika-prev").mousedown(function () {
            setTimeout(function () {
                changeDaysEvents();
            }, 1)
        });
        jQuery(".pika-select.pika-select-year").change(function () {
            setTimeout(function () {
                changeDaysEvents();
            }, 1)
        });
        jQuery(".pika-select.pika-select-month").change(function () {
            setTimeout(function () {
                changeDaysEvents();
            }, 1)
        });
        jQuery(".pika-button.pika-day").mousedown(function () {
            changeDays();
        })
    }

    document.addEventListener("DOMContentLoaded", function (event) {
        jQuery(".hs-dateinput").click(function () {
            setTimeout(function () {
                changeDaysEvents();
            }, 1);
        });
    });
    // end datepicker

}

function setFormValue(nombreInput, valorInput) {
    document.addEventListener("formBuild", function () {
        setTimeout(function (params) {
            let selec = 'hsForm_'+ideForm;
            let form;
            if(document.getElementById("hs-form-iframe-0") != null){
                form = document.getElementById("hs-form-iframe-0").contentDocument.getElementById(selec);
            }else{
                form = document.getElementById(selec);
            }
            
            if (form) {
                let input = form.querySelector(`[name='${nombreInput}']`);
                if (input) {
                    input.value = `${valorInput}`;
                    let opts = input.options;

                    if (opts && opts != undefined) {
                        for (var i = 0, n = opts.length; i < n; i++) {
                            if (opts[i].label && opts[i].value == valorInput) {
                                input.value = opts[i].value;
                                let changeEvent = new Event('change', { 'bubbles': true });
                                input.dispatchEvent(changeEvent);
                            }
                        }
                    }
                }
            }
        }, 500)
    });
}

function changeOptions(url, firstSelect, secondSelect) {
    document.addEventListener("formBuild", function () {
        setTimeout(function () {
        let select1 = document.getElementById("hs-form-iframe-0").contentDocument.getElementById(firstSelect + "-" + ideForm);
        fetch(url)
            .then((response) => response.json())
            .then((json) => {
                select1.addEventListener("change", function () {
                    let select2 = document.getElementById("hs-form-iframe-0").contentDocument.getElementById(secondSelect + "-" + ideForm);
                    let newOptions = `<option disabled value>Selecciona una opción</option>`;
                    for (let i = 0; i < json.length; i++) {
                        if (select1.value == json[i].key) {
                            newOptions = newOptions + `<option value="${json[i].value}">${json[i].value}</option>`;
                        }
                    }
                    select2.innerHTML = newOptions;
                    select2.value = "";
                })
            });
        })
    })
}