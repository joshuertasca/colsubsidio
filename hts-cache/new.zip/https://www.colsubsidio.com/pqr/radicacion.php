<!DOCTYPE html>
<!-- saved from url=(0100)https://www.colsubsidio.com/afiliados/servicio-al-cliente/felicitaciones-solicitudes-y-reclamos.html -->
<html lang="es">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <!--<base href="/">-->
        <base href="." />
        <!--script>document.write('<base href="' + document.location + '" />');</script-->
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, minimal-ui" name="viewport" />
        <title>Felicitaciones, solicitudes y reclamos - afiliados</title>
        <meta name="title" content="Felicitaciones, solicitudes y reclamos - afiliados" />
        <meta name="keywords" content="" />
        <meta name="description" content="Cuéntanos qué piensas sobre los productos y servicios de nuestra Caja de Compensación o cómo podemos mejorar para darte “todo lo que te mereces&amp;#8" />
        <meta name="robots" content="index,follow" />
        <meta property="og:locale" content="es_CO" />
        <meta property="og:type" content="object" />
        <meta property="og:image" content="index_files/Share_facebook_Colsubsidio.jpg" />
        <meta property="og:title" content="Felicitaciones, solicitudes y reclamos - afiliados" />
        <meta property="og:description" content="Cuéntanos qué piensas sobre los productos y servicios de nuestra Caja de Compensación o cómo podemos mejorar para darte “todo lo que te mereces&amp;#8" />
        <meta property="og:url" content="https://www.colsubsidio.com/afiliados/servicio-al-cliente/felicitaciones-solicitudes-y-reclamos.html" />
        <meta property="og:site_name" content="Colsubsidio" />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:description" content="Cuéntanos qué piensas sobre los productos y servicios de nuestra Caja de Compensación o cómo podemos mejorar para darte “todo lo que te mereces&amp;#8" />
        <meta name="twitter:title" content="" />
        <link rel="canonical" href="https://www.colsubsidio.com/afiliados/servicio-al-cliente/felicitaciones-solicitudes-y-reclamos.html" />
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700;800&family=Source+Sans+Pro:wght@200;300;400;600;700;900&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="./index_files/font-awesome.min.css" />
        <link rel="stylesheet" href="./index_files/app.css?ver=1324651523" />
        <!--link rel="stylesheet" href="https://www.colsubsidio.com/css/styles.css"-->
        <link href="css/styles.css?ver=51363714299" rel="stylesheet" />
        <link rel="stylesheet" href="./index_files/slick.css" />
        <link rel="stylesheet" href="./index_files/foundation-datepicker.css" />
        <link rel="stylesheet" href="./index_files/foundation-icons.css" />
        <link rel="stylesheet" href="./index_files/jquery.fancybox.css" />
        <!--<link rel="stylesheet" href="https://www.colsubsidio.com/css/jquery.fancybox.css">-->
        <link rel="stylesheet" href="./index_files/panorama_viewer.css" />
        <link rel="icon" href="https://fs.hubspotusercontent00.net/hubfs/7212050/favicon-1.png" type="image/x-icon" />
        

        <!-- Google Tag Manager -->
        <script>
        (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0], j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src= 'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f); })(window,document,'script','dataLayer','GTM-N24WDK3');
        </script>
        <!-- EndGoogle Tag Manager -->
        <!-- 1. Load libraries -->
        <!-- Polyfill(s) for older browsers -->
        <script src="./index_files/shim.min.js"></script> 
        <script src="./index_files/Reflect.js"></script>
        <script src="./index_files/system.src.js"></script>
        <script src="./index_files/systemjs.config.js"></script>

        <style>
            body.sup ul.tabs.pilares-categories-tabs li.tabs-title a,
            body.sup ul.tabs.pilares-home-tabs li.tabs-title a,
            body.sup ul.tabs.tabs-list li.tabs-title a {
                background: #011f5b;
            }
            body.sup ul.tabs.pilares-categories-tabs li.tabs-title.is-active,
            body.sup ul.tabs.pilares-home-tabs li.tabs-title.is-active,
            body.sup ul.tabs.tabs-list li.tabs-title.is-active {
                border-top: solid 4px #011f5b;
            }
            body.sup ul.tabs.pilares-categories-tabs li.tabs-title a,
            body.sup ul.tabs.pilares-home-tabs li.tabs-title a,
            body.sup ul.tabs.tabs-list li.tabs-title a {
                background-color: #011f5b;
            }
            body.sup ul.tabs.pilares-categories-tabs li.tabs-title.is-active,
            body.sup ul.tabs.pilares-home-tabs li.tabs-title.is-active,
            body.sup ul.tabs.tabs-list li.tabs-title.is-active {
                border-top: solid 4px #011f5b;
            }
            body.sup ul.tabs.pilares-categories-tabs li.tabs-title a,
            body.sup ul.tabs.pilares-home-tabs li.tabs-title a,
            body.sup ul.tabs.tabs-list li.tabs-title a {
                background: #011f5b;
            }
            body.sup ul.tabs.pilares-categories-tabs li.tabs-title:hover,
            body.sup ul.tabs.pilares-home-tabs li.tabs-title:hover,
            body.sup ul.tabs.tabs-list li.tabs-title:hover {
                border-top: solid 4px #feed01;
            }
        </style>
        <!-- <script src="./index_files/sdk.min.js" async=""></script>
        <script src="./index_files/j.php" type="text/javascript"></script> -->
        <meta class="foundation-mq" />
        <style type="text/css">
            .fancybox-margin {
                margin-right: 0px;
            }
        </style>
       <!-- <script src="./index_files/tag-127474f665bbf96ccdf92c88cdc59aa7.js" crossorigin="anonymous" type="text/javascript"></script> --> 
    </head>

    <body id="app-layout" class="serv afiliados" data-whatinput="mouse" sytle="padding-top: 0rem!important;">
        
        <!-- Google Tag Manager (noscript) -->
        <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N24WDK3"
        height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
        <!-- End Google Tag Manager (noscript) -->

        <!-- Segment Pixel - Tus beneficios - Colsubsidio - DO NOT MODIFY -->
        <img src="./index_files/seg" width="1" height="1" alt="" />
        <!-- End of Segment Pixel -->

        <!-- <link rel="preconnect" href="https://fonts.gstatic.com" />
<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@200;300;400;600;700;900&display=swap" rel="stylesheet" /> -->

<!-- CSS -->

<link rel="stylesheet" href="./css/bootstrap.min.css?ver=2" />
<link href="https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel="stylesheet" />

<link rel="shortcut icon" href="images/favicon.png" />

<link rel="stylesheet" href="https://cdn2.hubspot.net/hub/7212050/hub_generated/module_assets/41196033481/1639169281815/module_41196033481_HU02_Header_Empresas.min.css">
<link rel="stylesheet" href="https://cdn2.hubspot.net/hub/7212050/hub_generated/module_assets/48845314615/1639158786549/module_48845314615_search_input_custom.min.css">
<link rel="stylesheet" href="https://cdn2.hubspot.net/hub/7212050/hub_generated/module_assets/41661177088/1639159758905/module_41661177088_HU03_Buscador.min.css">
<link rel="stylesheet" href="https://cdn2.hubspot.net/hub/7212050/hub_generated/module_assets/41710158624/1639108593836/module_41710158624_HU09_Banner_Home.min.css">
<link rel="stylesheet" href="https://cdn2.hubspot.net/hub/7212050/hub_generated/module_assets/47720616296/1639091311159/module_47720616296_HU23A_Tipo_ancla.min.css">
<link rel="stylesheet" href="https://cdn2.hubspot.net/hub/7212050/hub_generated/module_assets/44128468344/1634327317744/module_44128468344_Separador_-_Lnea.min.css">
<link rel="stylesheet" href="https://cdn2.hubspot.net/hub/7212050/hub_generated/module_assets/45224670259/1620213600194/module_45224670259_HU52_Titulos.min.css">
<link rel="stylesheet" href="https://cdn2.hubspot.net/hub/7212050/hub_generated/module_assets/42419700481/1632342670044/module_42419700481_HU10_Barra_tienda_en_lnea.min.css">
<link rel="stylesheet" href="https://cdn2.hubspot.net/hub/7212050/hub_generated/module_assets/42545631768/1639091916986/module_42545631768_HU11_Cards_productos.min.css">
<link rel="stylesheet" href="https://cdn2.hubspot.net/hub/7212050/hub_generated/module_assets/41859929730/1639099220398/module_41859929730_HU12_Links_rpidos.min.css">
<link rel="stylesheet" href="https://cdn2.hubspot.net/hub/7212050/hub_generated/module_assets/41673821626/1639092032815/module_41673821626_HU15_Cards_Sorprndete.min.css">
<link rel="stylesheet" href="https://cdn2.hubspot.net/hub/7212050/hub_generated/module_assets/46338192015/1639091770320/module_46338192015_HU29_Card_noticias_con-sin_borde_New.min.css">

<!-- CSS FOOTER -->
<link rel="stylesheet" href="css/footer/Enlaces_de_inters_HU08.min.css" />
<link rel="stylesheet" href="css/footer/Seccin_Sguenos_HU07.min.css" />
<link rel="stylesheet" href="css/footer/Seccin_Concenos_HU06.min.css" />
<link rel="stylesheet" href="css/footer/Imagen_HU05.min.css" />
<link rel="stylesheet" href="css/footer/HU42A-Thumbnails_Extended.min.css" />
<link rel="stylesheet" href="css/footer/layout.min.css" />
<link rel="stylesheet" href="css/footer/styles.min.css" />
<link href="./css/styles.css?ver=21611502652" rel="stylesheet" />
<style>
    .container-cards h2.cards-title {
        margin-bottom: 15px;
        display: none;
    }
</style>
<style>
    a.cta_button {
        -moz-box-sizing: content-box !important;
        -webkit-box-sizing: content-box !important;
        box-sizing: content-box !important;
        vertical-align: middle;
    }
    .hs-breadcrumb-menu {
        list-style-type: none;
        margin: 0px 0px 0px 0px;
        padding: 0px 0px 0px 0px;
    }
    .hs-breadcrumb-menu-item {
        float: left;
        padding: 10px 0px 10px 10px;
    }
    .hs-breadcrumb-menu-divider:before {
        content: "›";
        padding-left: 10px;
    }
    .hs-featured-image-link {
        border: 0;
    }
    .hs-featured-image {
        float: right;
        margin: 0 0 20px 20px;
        max-width: 50%;
    }
    @media (max-width: 568px) {
        .hs-featured-image {
            float: none;
            margin: 0;
            width: 100%;
            max-width: 100%;
        }
    }
    .hs-screen-reader-text {
        clip: rect(1px, 1px, 1px, 1px);
        height: 1px;
        overflow: hidden;
        position: absolute !important;
        width: 1px;
    }
</style>

<!-- Google Tag Manager -->
<script>
    (function (w, d, s, l, i) {w[l] = w[l] || [];w[l].push({ "gtm.start": new Date().getTime(), event: "gtm.js" });var f = d.getElementsByTagName(s)[0],j = d.createElement(s),dl = l != "dataLayer" ? "&l=" + l : "";j.async = true;j.src = "https://www.googletagmanager.com/gtm.js?id=" + i + dl;f.parentNode.insertBefore(j, f);})(window, document, "script", "dataLayer", "GTM-N24WDK3");
</script>
<!-- End Google Tag Manager -->

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N24WDK3" height="0" width="0" style="display: none; visibility: hidden;"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<!-- CABEZOTE Y MENU ACCESIBILIDAD -->
<div class="header-container-wrapper">
        <div class="header-container">
            <div class="row-fluid-wrapper row-depth-1 row-number-1">
                <div class="row-fluid">
                    <div class="span12 widget-span widget-type-global_group" style="" data-widget-type="global_group" data-x="0" data-w="12">
                        <div class="" data-global-widget-path="generated_global_groups/47959324260.html">
                            <div class="row-fluid-wrapper row-depth-1 row-number-1">
                                <div class="row-fluid">
                                    <div class="span12 widget-span widget-type-custom_widget" style="" data-widget-type="custom_widget" data-x="0" data-w="12">
                                        <div id="hs_cos_wrapper_module_107290062" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module" style="" data-hs-cos-general-type="widget" data-hs-cos-type="module">
                                            <div id="skip-menu-bar" tabindex="0" class="skip-menu collapsed"><span>Omitir el menú</span></div>
                                            <div class="overlay-menu" id="overlay-menu"></div>
                                            <div class="header fixed">
                                                <div class="content">
                                                    <div class="logo">
                                                        <a href="https://www.colsubsidio.com/?hsLang=es" class="metricas-AccesosRapidos" data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar">
                                                            <img
                                                                src="https://fs.hubspotusercontent00.net/hubfs/7212050/Sitio%20.COM/new-content/nuevo-logo-colsubsidio-2021.svg"
                                                                alt="Colsubsidio caja de compensación familiar"
                                                                class="desktop"
                                                                loading="lazy"
                                                                width="170"
                                                                height="43"
                                                            />
                                                            <img
                                                                src="https://fs.hubspotusercontent00.net/hub/7212050/hubfs/Sitio%20.COM/new-content/home/tangram-colsubsidio.png?width=52&amp;height=52&amp;name=tangram-colsubsidio.png"
                                                                alt="Colsubsidio caja de compensación familiar"
                                                                class="mobile"
                                                                loading="lazy"
                                                                width="52"
                                                                height="52"
                                                                srcset="
                                                                    https://fs.hubspotusercontent00.net/hub/7212050/hubfs/Sitio%20.COM/new-content/home/tangram-colsubsidio.png?width=26&amp;height=26&amp;name=tangram-colsubsidio.png    26w,
                                                                    https://fs.hubspotusercontent00.net/hub/7212050/hubfs/Sitio%20.COM/new-content/home/tangram-colsubsidio.png?width=52&amp;height=52&amp;name=tangram-colsubsidio.png    52w,
                                                                    https://fs.hubspotusercontent00.net/hub/7212050/hubfs/Sitio%20.COM/new-content/home/tangram-colsubsidio.png?width=78&amp;height=78&amp;name=tangram-colsubsidio.png    78w,
                                                                    https://fs.hubspotusercontent00.net/hub/7212050/hubfs/Sitio%20.COM/new-content/home/tangram-colsubsidio.png?width=104&amp;height=104&amp;name=tangram-colsubsidio.png 104w,
                                                                    https://fs.hubspotusercontent00.net/hub/7212050/hubfs/Sitio%20.COM/new-content/home/tangram-colsubsidio.png?width=130&amp;height=130&amp;name=tangram-colsubsidio.png 130w,
                                                                    https://fs.hubspotusercontent00.net/hub/7212050/hubfs/Sitio%20.COM/new-content/home/tangram-colsubsidio.png?width=156&amp;height=156&amp;name=tangram-colsubsidio.png 156w
                                                                "
                                                                sizes="(max-width: 52px) 100vw, 52px"
                                                            />
                                                        </a>
                                                    </div>
                                                    <div class="header-item">
                                                        <!-- <div tabindex="0" class="item search-button">
        <span>Buscar</span>
        <img src="https://fs.hubspotusercontent00.net/hubfs/7212050/iconos/Buscador-negro.svg" alt="Buscador-negro" loading="lazy" width="25" height="24">
      </div> -->

                                                        <div
                                                            class="item metricas-AccesosRapidos"
                                                            tabindex="0"
                                                            id="boton-ingreso"
                                                            href="https://transacciones.colsubsidio.com/portalpersonas"
                                                            data-nombre="Ingresar"
                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                        >
                                                            <span>Ingresa al portal</span>
                                                            <img src="https://fs.hubspotusercontent00.net/hubfs/7212050/iconos/icono-ingresa-al-portal-negro.svg" alt="icono-ingresa-al-portal-negro" loading="lazy" width="24" height="25" />
                                                        </div>
                                                        <div class="item header-menu button-menu metricas-menú" tabindex="0" id="menu-openButton" data-categoria="Inicio" data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar">
                                                            <span>Menú</span>
                                                            <img src="https://fs.hubspotusercontent00.net/hubfs/7212050/icono-menu-hamburguesa.svg" alt="icono-menu-hamburguesa" loading="lazy" width="25" height="24" />
                                                        </div>
                                                        <div class="menu-lateral"></div>
                                                        <div id="sidebar" class="collapsed">
                                                            <button id="closer" tabindex="0" title="Cerrar menu" class="button-menu"><span class="texto-cerrar">Cerrar</span></button>
                                                            <div class="sidebar-content">
                                                                <span
                                                                    id="hs_cos_wrapper_module_107290062_menu_principal"
                                                                    class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_menu"
                                                                    style=""
                                                                    data-hs-cos-general-type="widget"
                                                                    data-hs-cos-type="menu"
                                                                >
                                                                    <div
                                                                        id="hs_menu_wrapper_module_107290062_menu_principal"
                                                                        class="hs-menu-wrapper active-branch no-flyouts hs-menu-flow-horizontal"
                                                                        role="navigation"
                                                                        data-sitemap-name="default"
                                                                        data-menu-id="41414642279"
                                                                        aria-label="Navigation Menu"
                                                                    >
                                                                        <ul role="menu" class="active-branch">
                                                                            <li class="hs-menu-item hs-menu-depth-1" role="none">
                                                                                <a
                                                                                    href="https://www.colsubsidio.com/empresas"
                                                                                    role="menuitem"
                                                                                    class="metricas-menu"
                                                                                    data-categoria="Ir a Empresas"
                                                                                    data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                >
                                                                                    Ir a Empresas
                                                                                </a>
                                                                            </li>
                                                                            <li class="hs-menu-item hs-menu-depth-1 active active-branch" role="none">
                                                                                <a
                                                                                    href="https://www.colsubsidio.com"
                                                                                    role="menuitem"
                                                                                    class="metricas-menu"
                                                                                    data-categoria="Inicio"
                                                                                    data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                >
                                                                                    Inicio
                                                                                </a>
                                                                            </li>
                                                                            <li class="hs-menu-item hs-menu-depth-1 hs-item-has-children" role="none">
                                                                                <a
                                                                                    href="javascript:;"
                                                                                    aria-haspopup="true"
                                                                                    aria-expanded="false"
                                                                                    role="menuitem"
                                                                                    class="metricas-menu"
                                                                                    data-categoria="Afíliate"
                                                                                    data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                >
                                                                                    Afíliate
                                                                                </a>
                                                                                <ul role="menu" class="hs-menu-children-wrapper">
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/afiliate/proceso"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Afíliate"
                                                                                            data-subcategoria="Proceso para afiliarte"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Proceso para afiliarte
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/afiliate/portal-transaccional"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Afíliate"
                                                                                            data-subcategoria="Sobre el portal transaccional"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Sobre el portal transaccional
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/afiliate/tams"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Afíliate"
                                                                                            data-subcategoria="Tarjeta de Afiliación Multiservicios"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Tarjeta de Afiliación Multiservicios
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/tus-beneficios"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Afíliate"
                                                                                            data-subcategoria="Tus beneficios"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Tus beneficios
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/afiliate"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Afíliate"
                                                                                            data-subcategoria="Todo sobre Afíliate"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Todo sobre Afíliate
                                                                                        </a>
                                                                                    </li>
                                                                                </ul>
                                                                                <span class="toggle"></span>
                                                                            </li>
                                                                            <li class="hs-menu-item hs-menu-depth-1 hs-item-has-children" role="none">
                                                                                <a
                                                                                    href="javascript:;"
                                                                                    aria-haspopup="true"
                                                                                    aria-expanded="false"
                                                                                    role="menuitem"
                                                                                    class="metricas-menu"
                                                                                    data-categoria="Empleándote"
                                                                                    data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                >
                                                                                    Empleándote
                                                                                </a>
                                                                                <ul role="menu" class="hs-menu-children-wrapper">
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/empleandote/enterate"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Empleándote"
                                                                                            data-subcategoria="Entérate"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Entérate
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/empleandote/inscribete/"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Empleándote"
                                                                                            data-subcategoria="Inscríbete"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Inscríbete
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/empleandote/capacitate"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Empleándote"
                                                                                            data-subcategoria="Capacítate y actualízate"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Capacítate y actualízate
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/empleandote/oportunidades"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Empleándote"
                                                                                            data-subcategoria="Busca oportunidades"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Busca oportunidades
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/empleandote"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Empleándote"
                                                                                            data-subcategoria="Todo sobre Empleándote"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Todo sobre Empleándote
                                                                                        </a>
                                                                                    </li>
                                                                                </ul>
                                                                                <span class="toggle"></span>
                                                                            </li>
                                                                            <li class="hs-menu-item hs-menu-depth-1 hs-item-has-children" role="none">
                                                                                <a
                                                                                    href="javascript:;"
                                                                                    aria-haspopup="true"
                                                                                    aria-expanded="false"
                                                                                    role="menuitem"
                                                                                    class="metricas-menu"
                                                                                    data-categoria="Apoyándote financieramente"
                                                                                    data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                >
                                                                                    Apoyándote financieramente
                                                                                </a>
                                                                                <ul role="menu" class="hs-menu-children-wrapper">
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/apoyo-financiero/subsidio"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Apoyándote financieramente"
                                                                                            data-subcategoria="Subsidios"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Subsidios
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/apoyo-financiero/creditos"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Apoyándote financieramente"
                                                                                            data-subcategoria="Créditos"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Créditos
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/apoyo-financiero/borron-y-cuenta-nueva"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Apoyándote financieramente"
                                                                                            data-subcategoria="Ley Borrón y Cuenta Nueva"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Ley Borrón y Cuenta Nueva
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/apoyo-financiero/seguros"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Apoyándote financieramente"
                                                                                            data-subcategoria="Seguros y asistencias"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Seguros y asistencias
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/apoyo-financiero/educacion"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Apoyándote financieramente"
                                                                                            data-subcategoria="Educación financiera"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Educación financiera
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/apoyo-financiero"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Apoyándote financieramente"
                                                                                            data-subcategoria="Todo sobre Apoyándote financieramente"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Todo sobre Apoyándote financieramente
                                                                                        </a>
                                                                                    </li>
                                                                                </ul>
                                                                                <span class="toggle"></span>
                                                                            </li>
                                                                            <li class="hs-menu-item hs-menu-depth-1 hs-item-has-children" role="none">
                                                                                <a
                                                                                    href="javascript:;"
                                                                                    aria-haspopup="true"
                                                                                    aria-expanded="false"
                                                                                    role="menuitem"
                                                                                    class="metricas-menu"
                                                                                    data-categoria="Vivienda"
                                                                                    data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                >
                                                                                    Vivienda
                                                                                </a>
                                                                                <ul role="menu" class="hs-menu-children-wrapper">
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/vivienda/proyectos/"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Vivienda"
                                                                                            data-subcategoria="Proyectos"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Proyectos
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/apoyo-financiero/subsidio/vivienda"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Vivienda"
                                                                                            data-subcategoria="Subsidios de vivienda"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Subsidios de vivienda
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/apoyo-financiero/creditos/vivienda"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Vivienda"
                                                                                            data-subcategoria="Créditos de vivienda"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Créditos de vivienda
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://la.studio.chubb.com/co/colsubsidio/residential/launchstage/es-CO?utm_medium=banner&amp;utm_source=web+sponsor&amp;utm_campaign=hogar+colsubsidio&amp;utm_content=desktop+hijo"
                                                                                            role="menuitem"
                                                                                            target="_blank"
                                                                                            rel="noopener"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Vivienda"
                                                                                            data-subcategoria="Seguros para el hogar"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Seguros para el hogar
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/vivienda/pago-cuota-inicial"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Vivienda"
                                                                                            data-subcategoria="Pago de cuota inicial"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Pago de cuota inicial
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/vivienda/post-venta"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Vivienda"
                                                                                            data-subcategoria=" Servicios Postventa"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Servicios Postventa
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/vivienda"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Vivienda"
                                                                                            data-subcategoria="Todo sobre Vivienda"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Todo sobre Vivienda
                                                                                        </a>
                                                                                    </li>
                                                                                </ul>
                                                                                <span class="toggle"></span>
                                                                            </li>
                                                                            <li class="hs-menu-item hs-menu-depth-1 hs-item-has-children" role="none">
                                                                                <a
                                                                                    href="javascript:;"
                                                                                    aria-haspopup="true"
                                                                                    aria-expanded="false"
                                                                                    role="menuitem"
                                                                                    class="metricas-menu"
                                                                                    data-categoria="Tu salud"
                                                                                    data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                >
                                                                                    Tu salud
                                                                                </a>
                                                                                <ul role="menu" class="hs-menu-children-wrapper">
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/tu-salud/ips"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Tu salud"
                                                                                            data-subcategoria="IPS Colsubsidio"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            IPS Colsubsidio
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/tu-salud/salud-preferencial"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Tu salud"
                                                                                            data-subcategoria="Salud Preferencial"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Salud Preferencial
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/tu-salud/medicamentos"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Tu salud"
                                                                                            data-subcategoria="Medicamentos"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Medicamentos
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/tu-salud/bioseguridad"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Tu salud"
                                                                                            data-subcategoria="COVID-19"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            COVID-19
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/tu-salud"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Tu salud"
                                                                                            data-subcategoria="Todo sobre Tu salud"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Todo sobre Tu salud
                                                                                        </a>
                                                                                    </li>
                                                                                </ul>
                                                                                <span class="toggle"></span>
                                                                            </li>
                                                                            <li class="hs-menu-item hs-menu-depth-1 hs-item-has-children" role="none">
                                                                                <a
                                                                                    href="javascript:;"
                                                                                    aria-haspopup="true"
                                                                                    aria-expanded="false"
                                                                                    role="menuitem"
                                                                                    class="metricas-menu"
                                                                                    data-categoria="Aprende"
                                                                                    data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                >
                                                                                    Aprende
                                                                                </a>
                                                                                <ul role="menu" class="hs-menu-children-wrapper">
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/aprende/primera-infancia"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Aprende"
                                                                                            data-subcategoria="Primera infancia"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Primera infancia
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/aprende/educacion"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Aprende"
                                                                                            data-subcategoria="Preescolar, primaria y bachillerato"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Preescolar, primaria y bachillerato
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/aprende/educacion-superior"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Aprende"
                                                                                            data-subcategoria="Educación tecnológica y técnica"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Educación tecnológica y técnica
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/aprende/educacion-continua"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Aprende"
                                                                                            data-subcategoria="Educación continua y cursos"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Educación continua y cursos
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/aprende/convenios"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Aprende"
                                                                                            data-subcategoria="Convenios para afiliados"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Convenios para afiliados
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/aprende/explora"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Aprende"
                                                                                            data-subcategoria="Explora y aprende"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Explora y aprende
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/aprende"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Aprende"
                                                                                            data-subcategoria="Todo sobre Aprende"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Todo sobre Aprende
                                                                                        </a>
                                                                                    </li>
                                                                                </ul>
                                                                                <span class="toggle"></span>
                                                                            </li>
                                                                            <li class="hs-menu-item hs-menu-depth-1 hs-item-has-children" role="none">
                                                                                <a
                                                                                    href="javascript:;"
                                                                                    aria-haspopup="true"
                                                                                    aria-expanded="false"
                                                                                    role="menuitem"
                                                                                    class="metricas-menu"
                                                                                    data-categoria="Desconéctate"
                                                                                    data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                >
                                                                                    Desconéctate
                                                                                </a>
                                                                                <ul role="menu" class="hs-menu-children-wrapper">
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/desconectate/deportes"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Desconéctate"
                                                                                            data-subcategoria="Actividad física y deportes"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Actividad física y deportes
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/desconectate/cultura"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Desconéctate"
                                                                                            data-subcategoria="Cultura y artes escénicas"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Cultura y artes escénicas
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/desconectate/esparcimiento"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Desconéctate"
                                                                                            data-subcategoria="Esparcimiento"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Esparcimiento
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/desconectate/turismo"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Desconéctate"
                                                                                            data-subcategoria="Turismo"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Turismo
                                                                                        </a>
                                                                                    </li>
                                                                                    <li class="hs-menu-item hs-menu-depth-2" role="none">
                                                                                        <a
                                                                                            href="https://www.colsubsidio.com/desconectate"
                                                                                            role="menuitem"
                                                                                            class="metricas-submenu"
                                                                                            data-categoria="Desconéctate"
                                                                                            data-subcategoria="Todo sobre Desconéctate"
                                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                        >
                                                                                            Todo sobre Desconéctate
                                                                                        </a>
                                                                                    </li>
                                                                                </ul>
                                                                                <span class="toggle"></span>
                                                                            </li>
                                                                            <li class="hs-menu-item hs-menu-depth-1" role="none">
                                                                                <a
                                                                                    href="https://www.colsubsidio.com/tiendas-en-linea/todas"
                                                                                    role="menuitem"
                                                                                    class="metricas-menu"
                                                                                    data-categoria="Tiendas en línea"
                                                                                    data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                >
                                                                                    Tiendas en línea
                                                                                </a>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </span>

                                                                <div class="hr">
                                                                    <hr />
                                                                </div>
                                                                <span
                                                                    id="hs_cos_wrapper_module_107290062_menu_footer"
                                                                    class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_simple_menu"
                                                                    style=""
                                                                    data-hs-cos-general-type="widget"
                                                                    data-hs-cos-type="simple_menu"
                                                                >
                                                                    <div
                                                                        id="hs_menu_wrapper_module_107290062_menu_footer"
                                                                        class="hs-menu-wrapper active-branch flyouts hs-menu-flow-horizontal"
                                                                        role="navigation"
                                                                        data-sitemap-name=""
                                                                        data-menu-id=""
                                                                        aria-label="Navigation Menu"
                                                                    >
                                                                        <ul role="menu">
                                                                            <li class="hs-menu-item hs-menu-depth-1" role="none">
                                                                                <a
                                                                                    href="https://www.colsubsidio.com/nosotros"
                                                                                    role="menuitem"
                                                                                    target="_self"
                                                                                    class="metricas-menu"
                                                                                    data-categoria="Quiénes somos"
                                                                                    data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                >
                                                                                    Quiénes somos
                                                                                </a>
                                                                            </li>
                                                                            <li class="hs-menu-item hs-menu-depth-1" role="none">
                                                                                <a
                                                                                    href="https://www.colsubsidio.com/consultanos"
                                                                                    role="menuitem"
                                                                                    target="_self"
                                                                                    class="metricas-menu"
                                                                                    data-categoria="Consúltanos"
                                                                                    data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                >
                                                                                    Consúltanos
                                                                                </a>
                                                                            </li>
                                                                            <li class="hs-menu-item hs-menu-depth-1" role="none">
                                                                                <a
                                                                                    href="https://www.colsubsidio.com/contactenos/centros-de-servicio#contact-center"
                                                                                    role="menuitem"
                                                                                    target="_blank"
                                                                                    rel="noopener"
                                                                                    class="metricas-menu"
                                                                                    data-categoria="Llámanos"
                                                                                    data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                >
                                                                                    Llámanos
                                                                                </a>
                                                                            </li>
                                                                            <li class="hs-menu-item hs-menu-depth-1" role="none">
                                                                                <a
                                                                                    href="https://www.magneto365.com/co/empresas/colsubsidio-talento-humano?utm_source=colsubsidioind&utm_medium=org&utm_campaign=trabajaconnosotros%7Cdigital&utm_content=linkbuilding"
                                                                                    role="menuitem"
                                                                                    target="_blank"
                                                                                    rel="noopener"
                                                                                    class="metricas-menu"
                                                                                    data-categoria="Trabaja con nosotros"
                                                                                    data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                >
                                                                                    Trabaja con nosotros
                                                                                </a>
                                                                            </li>
                                                                            <li class="hs-menu-item hs-menu-depth-1" role="none">
                                                                                <a
                                                                                    href="https://www.colsubsidio.com/sedes"
                                                                                    role="menuitem"
                                                                                    target="_self"
                                                                                    class="metricas-menu"
                                                                                    data-categoria="Localízanos"
                                                                                    data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                >
                                                                                    Localízanos
                                                                                </a>
                                                                            </li>
                                                                            <li class="hs-menu-item hs-menu-depth-1" role="none">
                                                                                <a
                                                                                    href="https://www.colsubsidio.com/proveedores"
                                                                                    role="menuitem"
                                                                                    target="_self"
                                                                                    class="metricas-menu"
                                                                                    data-categoria="Proveedores"
                                                                                    data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                >
                                                                                    Proveedores
                                                                                </a>
                                                                            </li>
                                                                            <li class="hs-menu-item hs-menu-depth-1" role="none">
                                                                                <a
                                                                                    href="https://ayuda.colsubsidio.com/"
                                                                                    role="menuitem"
                                                                                    target="_blank"
                                                                                    rel="noopener"
                                                                                    class="metricas-menu"
                                                                                    data-categoria="Centro de ayuda"
                                                                                    data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                >
                                                                                    Centro de ayuda
                                                                                </a>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div tabindex="-1" id="skipObject"></div>
                                                <script async="">
                                                    // $(document).ready(function () {
                                                    //     let menu_item = $("#sidebar .sidebar-content > span > div > ul").children();

                                                    //     let item1 = document.createElement("span");
                                                    //     item1.innerHTML = "Personas";
                                                    //     menu_item[2 - 1].append(item1);
                                                    // });
                                                </script>
                                            </div>
                                        </div>
                                    </div>
                                    <!--end widget-span -->
                                </div>
                                <!--end row-->
                            </div>
                            <!--end row-wrapper -->

                            <div class="row-fluid-wrapper row-depth-1 row-number-2">
                                <div class="row-fluid">
                                    <div class="search-wrapper">
                                        <div class="search-popup">
                                            <div id="search-module" class="span12 widget-span widget-type-cell" style="" data-widget-type="cell" data-x="0" data-w="12">
                                                <div class="row-fluid-wrapper row-depth-1 row-number-3">
                                                    <div class="row-fluid">
                                                        <div class="search-header">
                                                            <div class="search-close" tabindex="0"><img src="https://fs.hubspotusercontent00.net/hubfs/7212050/iconos/arrow-left.svg" alt="icono volver" /></div>

                                                            <div class="span12 widget-span widget-type-custom_widget search-input" style="" data-widget-type="custom_widget" data-x="0" data-w="12">
                                                                <div
                                                                    id="hs_cos_wrapper_module_162376627255619"
                                                                    class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module"
                                                                    style=""
                                                                    data-hs-cos-general-type="widget"
                                                                    data-hs-cos-type="module"
                                                                >
                                                                    <div class="hs-search-field">
                                                                        <div class="hs-search-field__bar">
                                                                            <form action="/resultados-de-busqueda" method="get" data-hs-cf-bound="true">
                                                                                <label for="search-input-f" tabindex="-1">Buscar</label>

                                                                                <input type="text" id="search-input-f" class="hs-search-field__input" name="term" autocomplete="off" aria-label="Buscar" placeholder="¿Qué estás buscando?" />

                                                                                <input type="hidden" name="type" value="SITE_PAGE" />

                                                                                <input type="hidden" name="type" value="BLOG_POST" />
                                                                                <input type="hidden" name="type" value="LISTING_PAGE" />

                                                                                <input type="hidden" name="type" value="KNOWLEDGE_ARTICLE" />

                                                                                <button aria-label="Buscar" class="search-button-submit" type="submit" title="Boton buscar">
                                                                                    <img alt="Boton buscar" src="https://fs.hubspotusercontent00.net/hubfs/7212050/icono-buscar.svg" />
                                                                                </button>
                                                                            </form>
                                                                        </div>
                                                                        <ul class="hs-search-field__suggestions">
                                                                            <li id="li_placeholder">...</li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--end widget-span -->
                                                        </div>
                                                    </div>
                                                    <!--end row-->
                                                </div>
                                                <!--end row-wrapper -->

                                                <div class="row-fluid-wrapper row-depth-1 row-number-4">
                                                    <div class="row-fluid">
                                                        <div class="span12 widget-span widget-type-custom_widget" style="" data-widget-type="custom_widget" data-x="0" data-w="12">
                                                            <div
                                                                id="hs_cos_wrapper_module_326667253"
                                                                class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module"
                                                                style=""
                                                                data-hs-cos-general-type="widget"
                                                                data-hs-cos-type="module"
                                                            >
                                                                <div class="square-wrapper">
                                                                    <div class="busquedas-container">
                                                                        <h3>Búsquedas populares Colsubsidio Personas</h3>
                                                                        <div class="busquedas-content">
                                                                            <div class="busquedas-links-left">
                                                                                <a href="https://www.medicamentoscolsubsidio.com.co/#/inicio" target="_blank" rel="noopener">
                                                                                    ¿Cómo solicito medicamentos en línea?
                                                                                </a>

                                                                                <a href="https://www.colsubsidio.com/afiliate/virtual?hsLang=es" target="_blank" rel="noopener">
                                                                                    ¿Cómo gestiono mi afiliación virtualmente?
                                                                                </a>

                                                                                <a href="https://www.colsubsidio.com/vivienda/proyectos/?hsLang=es" target="_blank" rel="noopener">
                                                                                    ¿Dónde puedo ver proyectos de vivienda?
                                                                                </a>
                                                                            </div>
                                                                            <div class="busquedas-links-right">
                                                                                <a href="https://www.colsubsidio.com/tiendas-en-linea/todas?hsLang=es" target="_blank" rel="noopener">
                                                                                    ¿Cuáles son las tiendas en línea de Colsubsidio?
                                                                                </a>

                                                                                <a href="https://www.colsubsidio.com/apoyo-financiero/subsidio/monetario/familiar?hsLang=es" target="_blank" rel="noopener">
                                                                                    ¿Cómo solicito mi subsidio familiar?
                                                                                </a>

                                                                                <a href="https://transacciones.colsubsidio.com/credito/lineas-de-credito/" target="_blank" rel="noopener">
                                                                                    ¿Cómo puedo pedir créditos en línea?
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!--end widget-span -->
                                                    </div>
                                                    <!--end row-->
                                                </div>
                                                <!--end row-wrapper -->

                                                <div class="row-fluid-wrapper row-depth-1 row-number-5">
                                                    <div class="row-fluid">
                                                        <div class="span12 widget-span widget-type-custom_widget" style="" data-widget-type="custom_widget" data-x="0" data-w="12">
                                                            <div
                                                                id="hs_cos_wrapper_module_247225075"
                                                                class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module"
                                                                style=""
                                                                data-hs-cos-general-type="widget"
                                                                data-hs-cos-type="module"
                                                            >
                                                                <div class="help container" id="">
                                                                    <div class="content square-wrapper">
                                                                        <h2>¿Necesitas ayuda?</h2>
                                                                        <div class="content-item">
                                                                            <div class="item">
                                                                                <div class="img">
                                                                                    <img src="https://fs.hubspotusercontent00.net/hubfs/7212050/icono-necesitas-ayuda-contactanos.svg" alt="icono-necesitas-ayuda-contactanos" />
                                                                                </div>
                                                                                <div class="text">
                                                                                    <h3>Contáctanos</h3>

                                                                                    <p></p>
                                                                                    <a
                                                                                        href="https://www.colsubsidio.com/contactenos?hsLang=es"
                                                                                        class="metricas-ayuda"
                                                                                        data-ayuda=" Entra aquí para ponerte en contacto con nosotros "
                                                                                        data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                    >
                                                                                        Entra aquí para ponerte en contacto con nosotros
                                                                                    </a>
                                                                                </div>
                                                                            </div>

                                                                            <div class="item">
                                                                                <div class="img">
                                                                                    <img src="https://fs.hubspotusercontent00.net/hubfs/7212050/icono-necesitas-ayuda-llamanos.svg" alt="icono-necesitas-ayuda-llamanos" />
                                                                                </div>
                                                                                <div class="text">
                                                                                    <h3>Llámanos de 7 a.m. a 7 p.m.</h3>

                                                                                    <p></p>
                                                                                    <a
                                                                                        href="https://www.colsubsidio.com/contactenos/centros-de-servicio?hsLang=es#contact-center"
                                                                                        target="_blank"
                                                                                        rel="noopener"
                                                                                        class="metricas-ayuda"
                                                                                        data-ayuda=" Mira nuestras líneas de atención telefónica. "
                                                                                        data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                    >
                                                                                        Mira nuestras líneas de atención telefónica.
                                                                                    </a>
                                                                                </div>
                                                                            </div>

                                                                            <div class="item">
                                                                                <div class="img">
                                                                                    <img src="https://fs.hubspotusercontent00.net/hubfs/7212050/icono-necesitas-ayuda-localizanos.svg" alt="icono-necesitas-ayuda-localizanos" />
                                                                                </div>
                                                                                <div class="text">
                                                                                    <h3>Localízanos</h3>

                                                                                    <p></p>
                                                                                    <a
                                                                                        href="https://www.colsubsidio.com/sedes?hsLang=es"
                                                                                        class="metricas-ayuda"
                                                                                        data-ayuda=" Ubica aquí uno de nuestros centros de servicio más cercano. "
                                                                                        data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                                    >
                                                                                        Ubica aquí uno de nuestros centros de servicio más cercano.
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!--end widget-span -->
                                                    </div>
                                                    <!--end row-->
                                                </div>
                                                <!--end row-wrapper -->
                                            </div>
                                            <!--end widget-span -->
                                        </div>
                                    </div>
                                </div>
                                <!--end row-->
                            </div>
                            <!--end row-wrapper -->
                        </div>
                    </div>
                    <!--end widget-span -->
                </div>
                <!--end row-->
            </div>
            <!--end row-wrapper -->
        </div>
        <!--end header -->
    </div>
    <!-- FIN CABEZOTE Y MENU ACCESIBILIDAD -->

<style>
    .header.fixed {
        top: 0;
    }
</style>
        <div class="box-miga-de-pan">
            <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="https://www.colsubsidio.com/">Inicio</a></li>
                <li class="breadcrumb-item active"><a href="https://www.colsubsidio.com/pqr">PQR</a></li>
                <li class="breadcrumb-item" aria-current="page" id="lbl_nombre_proyecto">Radicación</li>
            </ol>
            </nav>
        </div>
            <div class="ico-text-retro">
                <div class="container ps_relative">
                    <h1 class="text-retro">Solicitudes, felicitaciones, reclamos o sugerencias</h1>
                    <p class="text-center">En esta sección podrás enviarnos la opinión que tienes de nuestros servicios en Colsubsidio, a continuación podrás ingresar tus datos y comentarios:</p>
                    <!-- <div class="btn-cons-pqr">
                        <a href="./estado-de-solicitud" class="btn btn-primary cta">Consultar estado de PQR</a>
                    </div> -->
                </div>
            </div>

        <script type="text/javascript" id="">
            !(function (b, e, f, g, a, c, d) {
                b.fbq ||
                    ((a = b.fbq = function () {
                        a.callMethod ? a.callMethod.apply(a, arguments) : a.queue.push(arguments);
                    }),
                    b._fbq || (b._fbq = a),
                    (a.push = a),
                    (a.loaded = !0),
                    (a.version = "2.0"),
                    (a.queue = []),
                    (c = e.createElement(f)),
                    (c.async = !0),
                    (c.src = g),
                    (d = e.getElementsByTagName(f)[0]),
                    d.parentNode.insertBefore(c, d));
            })(window, document, "script", "https://connect.facebook.net/en_US/fbevents.js");
            fbq("init", "1185583431520632");
            fbq("track", "PageView");
        </script>
        <noscript>
            <img height="1" width="1" src="https://www.facebook.com/tr?id=1185583431520632&amp;ev=PageView&amp;noscript=1" />
        </noscript>
      
        <div class="master-wrapper">
            <section class="formulario_inline">
            <div class="separador-c"></div>
                        <div class="form-container">
                            <div class="form-wrapper columns">
                                <form
                                    action="controler.php"
                                    method="POST"
                                    enctype="multipart/form-data"
                                    name="formulario-integración-servicio-5"
                                    class="form-envio"
                                    id="formulario-integración-servicio-5-5"
                                    btn-submit="bt-submit-5" 
                                >
                                <div class="container">
                                <h2>Información personal</h2>
                                <div class="separador-c"></div>
                                    <div class="row">
                                        <div class="columns" for="input_5_5" id="span_input_5">
                                            <label>Primer Nombre</label>
                                            <input label-text="Primer Nombre" aria-label="Digita primer nombre"  placeholder="" required="true" id="input_5_5" name="input_5" type="text" value="" aria-required="true"
                                            onkeyup="this.value=PrimerNombreCaracteres(this.value)"/>
                                            <label for="input_5_5" class="error" id="errInput_5_5"></label>
                                        </div>

                                        <div class="columns" for="input_5_6" id="span_input_6">
                                            <label>Segundo Nombre <em>(Opcional)</em></label>
                                            <input label-text="Segundo Nombre" aria-label="Digita segundo nombre"  placeholder="" required="false" id="input_5_6" name="input_6" type="text" value="" aria-required="true"
                                            onkeyup="this.value=SegundoNombreCaracteres(this.value)"/>
                                            <label for="input_5_6" class="error" id="errInput_5_6"></label>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="columns" for="input_7" id="span_input_7">
                                            <label>Primer Apellido</label>
                                            <input label-text="Primer Apellido" aria-label="Digita primer apellido"  placeholder="" required="true" id="input_5_7" name="input_7" type="text" value="" aria-required="true"
                                            onkeyup="this.value=PrimerApellidoCaracteres(this.value)"/>
                                            <label for="input_5_7" class="error" id="errInput_5_7"></label>
                                        </div>
                                        <div class="columns" for="input_8" id="span_input_8">
                                            <label>Segundo Apellido</label>
                                            <input label-text="Segundo Apellido" aria-label="Digita segundo apellido"  placeholder="" required="false" id="input_5_8" name="input_8" type="text" value="" aria-required="true"
                                            onkeyup="this.value=SegundoApellidoCaracteres(this.value)"/>
                                            <label for="input_5_8" class="error" id="errInput_5_8"></label>
                                        </div>
                                    </div>
                                    <div class="row">
                                    <div class="columns label_titulo" for="input_2" id="span_input_2" style="display: block;">
                                    <label for="input_2">Tipo de documento</label>
                                            <div class="container-group-radio" isrequired="true" id="input_5_2_1">
                                            	<select
                                                	label-text="Tipo de documento"
                                                	id="input_2"
                                                    required="true"
                                                	class="changeable"
                                                	name="input_2"
                                                	idchangeable="input_2"
                                                    showwhenis="input_16_Persona Natural"
                                                    onchange = "clearDocumentField();validacion_tipodocu_select(this)"
                                                    >
                                            		<option value="">Selecciona una opción</option>
                                                    <option value="AN">Anónimo</option>
                                            		<option value="CC">Cédula Ciudadanía</option>
                                            		<option value="CE">Cédula Extranjería</option>
                                                    <option value="CD">Carnet Diplomatico</option>
                                                    <option value="NI">NIT</option>
                                                    <option value="NP">NUIP</option>
                                                    <option value="PP">Pasaporte</option>
                                                    <!--
                                                    <option value="PE">Permiso Especial De Permanencia</option>
                                                    <option value="RC">Registro Civil</option>
                                                    <option value="TI">Tarjeta De Identidad</option>
                                                    <option value="RU">RUT</option>
                                                    -->
                                                    
                                                    
                                            	</select>
                                                <div for="input_2" class="error" style="display: none;">Campo requerido</div>
                                            </div>
                                        </div>
                                        
                                        <div class="columns" for="input_5_3" id="span_input_3">
                                        <label>Número de documento</label>
                                            <input
                                            aria-label="Digita tu Número de documento"
                                            label-text="Identificación"
                                                placeholder="Ej: 12345678"
                                                required="true"
                                                id="input_5_3"
                                                name="input_3"
                                                type="text"
                                                value=""   
                                                minlength="3"
                                             />
                                        <label for="input_5_3" class="error" id="errInput_5_3"></label>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="columns" for="input_15" id="span_input_15">
                                            <label for="input_15">Estado del cliente</label>
                                            <div class="container-group-radio" isrequired="true" id="input_5_15_1">
                                            	<select
                                                	label-text="Tipo de Cliente"
                                                	id="input_15"
                                                    required="true" 
                                                	class="changeable"
                                                	name="input_15">
                                            		<option value="">Selecciona una opción</option>
                                            		<option value="Afiliado_Vigente">Afiliado Vigente</option>
                                            		<option value="No_Afiliado">No Afiliado</option>
                                            		<option value="Afiliado_Retirado">Afiliado Retirado</option>
                                                    <option value="Beneficiario">Beneficiario</option>
                                                    <option value="Pensionado">Pensionado</option>
                                                    <option value="Independiente_Vigente">Independiente Vigente</option>
                                                    <option value="Independiente_No_afiliado">Independiente No afiliado</option>
                                                    <option value="Independiente_retirado">Independiente retirado</option>
                                            	</select>
                                                <div class="error" style="display: none;">Campo requerido</div>
                                            </div>
                                        </div>
                                        
                                        <div class="columns"></div>
                                        
                                    </div>


                                    <div class="separador-r"></div>
                                    <h2>Si eres proveedor, ingresa estos datos</h2>
                                    <div class="row">
                                    <div class="columns label_titulo" id="span_input_16">
                                            <label  for="input_16" id="span_input_16">
                                                Tipo de cuenta 
                                                <em>(Opcional)</em>
                                                <button type="button" class="btn btn-secondary" aria-label="Si representas una empresa selecciona persona jurídica, si el servicio es para ti escoge persona natural" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Si representas una empresa selecciona persona jurídica, si el servicio es para ti escoge persona natural">
                                                </button>
                                            </label>
                                            <div for="input_16" bclass="container-group-radio" isrequired="true" id="input_5_16_1">
                                            	<!--aqui jhon -->
                                            	<select
                                                	label-text="Tipo de Cuenta"
                                                	id="input_16"
                                                	class="changeable"
                                                	name="input_16"
                                                	idchangeable="input_16"
                                                    idassociated="input_2,input_23"
                                            	>
                                            		<option value="">Selecciona una opción</option>
                                            		<option value="Persona Natural">Persona Natural</option>
                                            		<option value="Persona Juridica">Persona Juridica</option>
                                            	</select>
                                            	<!-- aqui Jhon -->
                                                <div for="input_16" class="error" style="display: none;">Campo requerido</div>
                                            </div>
                                        </div>
                                        <div class="columns" for="input_5_4" id="span_input_4">
                                            <label>Razón social <em>(Opcional)</em></label>
                                            <input label-text="Razón Social" aria-label="Digita la razón social"  placeholder="" id="input_5_4" name="input_4" type="text" value="" aria-required="true" />
                                        </div>
                                    </div>
                                    <div class="separador-k"></div>
                                </div>
                                <div class="bg_blue">
                                    <div class="container">
                                        <div class="separador-k"></div>
                                        <h2>Datos de contacto</h2>
                                        <div class="row">
                                            <div class="columns" for="input_11" id="span_input_11">
                                                <label class="label-text">Número de teléfono móvil</label>
                                                <input aria-label="Digita teléfono celular" label-text="Teléfono Celular" minlength="10" placeholder="Ej: 312 1234567" required="true" id="input_5_11"
                                                onkeyup="func_val_celular()" name="input_11" type="text" value="" />
                                                <label for="input_5_11" class="error" id="errInput_5_11"></label>
                                            </div>
                                            <div class="columns" for="input_14" id="span_input_14">
                                                <label class="label-text">Número de teléfono</em></label>
                                                <input aria-label="Digita teléfono de la casa" label-text="Teléfono fijo" minlength="10" placeholder="Ej: 601 1234567" required="false" id="input_5_14"
                                                 onkeyup="func_val_tel();" name="input_14" type="text" value="" aria-required="true" />
                                                <label for="input_5_14" class="error" id="errInput_5_14"></label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="columns" for="input_12" id="span_input_12">
                                                <label class="label-text">Teléfono oficina <em>(Opcional)</em></label>
                                                <input aria-label="Digita teléfono oficina" label-text="Teléfono Oficina" minlength="10" placeholder="Ej: 601 1234567" required="false" id="input_5_12" name="input_12" type="text" value="" aria-required="true"
                                                    onkeyup="func_val_tel2();"/>
                                                <label for="input_5_12" class="error" id="errInput_5_12"></label>
                                            </div>
                                            <div class="columns" for="input_13" id="span_input_13">
                                                <label class="label-text">Extensión <em>(Opcional)</em></label>
                                                <input label-text="Ext" aria-label="Digita la extensión" placeholder="" required="false" id="input_5_13" name="input_13" type="text" value="" aria-required="true"
                                                onkeyup="this.value=extOficina(this.value)"/>
                                                <label for="input_5_13" class="error" id="errInput_5_13"></label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="columns" for="input_10" id="span_input_10">
                                                <label class="label-text">Correo electrónico</label>
                                                <input label-text="Correo" aria-label="Digita el correo electrónico" placeholder="ejemplo@ejemplo.com" required="true" id="input_5_10" name="input_10" type="email" value="" />
                                            </div>
                                                                                        <div class="columns" for="input_17" id="span_input_17">
                                                <label for="input_17">Departamento</label>
                                                <div class="container-group-radio" isrequired="true" id="input_5_17_1">
                                                    <select
                                                        label-text="Departamento de residencia"
                                                        id="input_17"
                                                        required="true" 
                                                        class="changeable"
                                                        name="input_17"
                                                        onchange="cargaCiudades(event)"
                                                        >
                                                        <option value="">Selecciona una opción</option>
                                                                                                                    <option value="0">Amazonas</option>
                                                                                                                    <option value="1">Antioquia</option>
                                                                                                                    <option value="2">Arauca</option>
                                                                                                                    <option value="3">Atlántico</option>
                                                                                                                    <option value="4">Bolívar</option>
                                                                                                                    <option value="5">Boyacá</option>
                                                                                                                    <option value="6">Caldas</option>
                                                                                                                    <option value="7">Caquetá</option>
                                                                                                                    <option value="8">Casanare</option>
                                                                                                                    <option value="9">Cauca</option>
                                                                                                                    <option value="10">Cesar</option>
                                                                                                                    <option value="11">Chocó</option>
                                                                                                                    <option value="12">Cundinamarca</option>
                                                                                                                    <option value="13">Córdoba</option>
                                                                                                                    <option value="14">Guainía</option>
                                                                                                                    <option value="15">Guaviare</option>
                                                                                                                    <option value="16">Huila</option>
                                                                                                                    <option value="17">La Guajira</option>
                                                                                                                    <option value="18">Magdalena</option>
                                                                                                                    <option value="19">Meta</option>
                                                                                                                    <option value="20">Nariño</option>
                                                                                                                    <option value="21">Norte de Santander</option>
                                                                                                                    <option value="22">Putumayo</option>
                                                                                                                    <option value="23">Quindío</option>
                                                                                                                    <option value="24">Risaralda</option>
                                                                                                                    <option value="25">San Andrés y Providencia</option>
                                                                                                                    <option value="26">Santander</option>
                                                                                                                    <option value="27">Sucre</option>
                                                                                                                    <option value="28">Tolima</option>
                                                                                                                    <option value="29">Valle del Cauca</option>
                                                                                                                    <option value="30">Vaupés</option>
                                                                                                                    <option value="31">Vichada</option>
                                                                                                            </select>
                                                    <div class="error" style="display: none;">Campo requerido</div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="columns" for="input_18" id="span_input_18">
                                                <label for="input_18">Ciudad</label>
                                                <div class="container-group-radio" isrequired="true" id="input_5_18_1">
                                                    <select
                                                        label-text="Ciudad de expedición de documento"
                                                        id="input_18"
                                                        required="true" 
                                                        class="changeable"
                                                        name="input_18">
                                                        <option value="">Selecciona una opción</option>
                                                    </select>
                                                    <div class="error" style="display: none;">Campo requerido</div>
                                                </div>
                                            </div>
                                                                                        
                                            
                                            <div class="columns" for="input_9" id="span_input_9">
                                                <label class="label-text">Dirección</label>
                                                <input label-text="Dirección" aria-label="Digita la dirección" placeholder="" required="true" id="input_5_9" name="input_9" type="text" value="" aria-required="true"
                                                onkeyup="this.value=DireccionCaracteres(this.value)"/>
                                                <label for="input_5_9" class="error" id="errInput_5_9"></label>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="separador-k"></div>

                                </div>

                                <div class="container">
                                    <div class="separador-k"></div>
                                    <h2>Déjanos tu comentario</h2>
                                    <div class="separador-c"></div>
                                    <div class="row">
                                        <div class="columns" for="input_20" id="span_input_20">
                                            <label for="input_20" class="label-text">Tipo de Contacto</label>
                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tooltipModal"></button>
                                            <div class="container-group-radio" isrequired="true" id="input_5_20_1">
                                                <select
                                                	label-text="Tipo de Contacto"
                                                	id="input_20"
                                                	class="changeable"
                                                	name="input_20"
                                                    required="true" 
                                            	>
                                            		<option value="">Selecciona una opción</option>
                                            		<option value="Peticion">Petición</option>
                                            		<option value="Queja/Reclamo">Queja/Reclamo</option>
                                            		<option value="SolicitudDeInformacion">Solicitud de Información</option>
                                            		<option value="Felicitacion">Felicitación</option>
                                                    <option value="Sugerencia/Propuesta">Sugerencia/Propuesta</option>
                                            	</select>
                                                <div for="input_20" class="error" style="display: none;">Campo requerido</div>
                                            </div>
                                            <!-- Modal -->
                                            <div class="modal fade" id="tooltipModal" tabindex="-1" aria-labelledby="tooltipModalLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                        <div class="modal-body">
                                                            <img src="images/icoAtencion.svg" alt="Atencion">
                                                            <h2>Temas de contacto</h2>
                                                            <p><strong>Felicitación:</strong> Es cuando se resaltan aspectos positivos de la corporación, la excelencia en el desempeño o actitud de un colaborador durante la prestación del servicio.</p>
                                                            <p><strong>Sugerencia:</strong> Es una propuesta para incidir en el mejoramiento de diferentes factores en la corporación (infraestructura, procesos, herramientas, etc.)</p>
                                                            <p><strong>Petición / solicitud:</strong> Es la solicitud formal de información o trámite.</p>
                                                            <p><strong>Reclamo:</strong> Es la inconformidad de un cliente por incumplimientos de la promesa realizada por la corporación inherentes a la prestación de un servicio o producto.</p>
                                                            <p><strong>Queja:</strong> Cuando el cliente manifiesta inconformidad por incumplimiento en los protocolos de comportamiento del trabajador (conducta, acción u omisión) durante la prestación del servicio.</p>
                                                        </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="columns" for="input_21" id="span_input_21">
                                            <label class="label-text" for="input_21">Tema de contacto</label>
                                            <select required="true"  label-text="Tema Contacto" id="input_21" name="input_21" class="changeable">
                                                <option value="Afiliaciones" selected="selected">Afiliaciones</option>
                                                <option value="Salud">Salud</option>
                                                <option value="droguerias_compra_medicamentos">Droguerias Compra medicamentos</option>
                                                <option value="Credito_y_Seguros">Crédito y Seguros</option>
                                                <option value="Digital_Credito_al_Clic">Digital Crédito al Clic</option>
                                            	<option value="Medicamentos_EPS">Medicamentos EPS</option>
                                                <option value="Otro">Otro</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="columns" for="input_22" id="span_input_22">
                                            <label class="label-text">Mensaje</label>
                                        </div>
                                        <textarea maxlength="4500" class="changeable" aria-label="Escribe el mensaje o motivo de la PQRS" label-text="Mensaje" placeholder="Escribe tu comentario" required="true" id="input_5_22" name="input_22" cols="50" rows="10" aria-required="true"></textarea>
                                    </div>

                                    <div class="row">
                                        <div class="columns">
                                            <label class="label-text" for="input_85">Medio de respuesta</label>
                                            <select label-text="Medio de respuesta" id="input_85" name="input_85"
                                             required="true" onchange="funcMedioDeRespuesta()" class="changeable">
                                                <option value="" selected>Selecciona una opción</option>
                                                <option value="correo">Correo electrónico</option>
                                                <option value="correspondencia">Dirección de correspondencia</option>
                                            </select>
                                            <div for="input_85" class="error" style="display: none;">Campo requerido</div>
                                        </div>

                                        <div class="columns">
                                            <div id="input_83" style="display: none;">
                                                <label for="input_82">Correo de respuesta</label>
                                                <input type="email" name="input_82" id="input_82" placeholder="Ej: correo@ejemplo.com">
                                            </div>
                                        </div>

                                    </div>

                                    
                                    <div id="input_84" style="display: none;">
                                        <div class="row">
                                            <div class="col">
                                            <label class="label-text">Dirección de correspondencia</label>
                                                <select id="input_81" name="input_81">
                                                    <option value="" selected>Selecciona una opción</option>
                                                    <option value="anillo">Anillo</option>
                                                    <option value="autopista">Autopista</option>
                                                    <option value="avenida">Avenida</option>
                                                    <option value="avenida_calle">Avenida calle</option>
                                                    <option value="avenida_carrera">Avenida carrera</option>
                                                    <option value="calle">Calle</option>
                                                    <option value="carrera">Carrera</option>
                                                    <option value="diagonal">Diagonal</option>
                                                    <option value="transversal">Transversal</option>
                                                    <option value="zona">Zona</option>
                                                </select>
                                            </div>
 

                                            <div class="columns">
                                                <label  for="input_80">Dirección</label>
                                                <input type="text" name="input_80" id="input_80" placeholder="Ej: 12B bis" >  
                                            </div>
 

                                            <div class="col">
                                            <label class="label-text" for="input_79">#</label>
                                                <input type="text" name="input_79" id="input_79" placeholder="Ej: 26 Sur">
                                            <div for="input_79" class="error" style="display: none;">Campo requerido</div>
                                            </div>

                                            <div class="col">
                                            <label class="label-text" for="input_78">-</label>
                                                <input type="text" name="input_78" id="input_78" placeholder="Ej: 58">
                                            <div for="input_78" class="error" style="display: none;">Campo requerido</div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col">
                                                <label for="">Apartamento</label>
                                                <input type="text" name="input_77" id="input_77">
                                            </div>

                                            <div class="col">
                                                <label for="">Habitación</label>
                                                <input type="text" name="input_76" id="input_76">
                                            </div>

                                            <div class="col">
                                                <label for="">Bloque</label>
                                                <input type="text" name="input_75" id="input_75">
                                            </div>

                                            <div class="col">
                                                <label for="">Edificio</label>
                                                <input type="text" name="input_74" id="input_74">
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col">
                                                <label for="">Barrio / Vereda</label>
                                                <input type="text" name="input_73" id="input_73">
                                            </div>
                                        </div>
                                    </div>

                                    
                                    <div class="separador-k"></div>
                                    <div class="row">
                                        <div class="columns tipo_archivo" for="input_25" id="span_input_25">
                                            <div class="archivo_tipo">
                                                <label class="label-text">Evidencias o adjuntos <em>(Opcional)</em></label>
                                                <input required="false" aria-label="Si considera necesario adjunte documento máximo 500 kilobytes" label-text="Adjunto" maxfilesize="6" id="input_5_25" name="input_25" type="file" aria-required="true" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <!-- <label class="columns" for="input_66" id="span_input_66">
                                            <div class="label-text">Acepto la autorización para la utilización de datos personales</div>
                                            <select label-text="Acepto la autorización para la utilización de datos personales" id="input_66" name="input_66">
                                                <option value="si">si</option>
                                                <option value="si">si</option>Selecciona una opción
                                                <option value="no">no</option>
                                            </select>
                                        </label> -->
                                        <div class="columns block-html">
                                            <div class="wht_content">
                                                <div class="form-check">
                                                    <input type="checkbox" required="true" id="input_66" name="input_66" type="text" value="" aria-required="true" class="error" aria-invalid="true">
                                                    <label id="input_66-error" class="error" style="display:none" for="input_66">Campo requerido</label>
                                                     <label class="label-text form-check-label pst_text" for="input_66">
                                                        Al enviar la información autorizas:
                                                        <a href="https://www.colsubsidio.com/tratamiento-de-datos" target="_blank" tracked="1">
                                                        la política de tratamiento de datos personales</a>,
                                                        <a href="https://www.colsubsidio.com/hubfs/documentos/colsubsidio/autorizacion-para-la-utilizacion-de-datos-personales-colsubsidio.pdf" target="_blank" tracked="1">
                                                        la autorización para la utilización de datos personales
                                                        </a>
                                                        y 
                                                        <a href="https://www.colsubsidio.com/hubfs/documentos/colsubsidio/aviso-de-privacidad-de-colsubsidio.pdf" target="_blank" tracked="1">
                                                        el aviso de privacidad</a>.
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="columns"></div>
                                        <div class="columns">
                                            <!--
                                            //6Ld2MF4jAAAAAE7NlF8gZt6GC6eACoyPFif1iOOP dev
                                            //6LeDvsAZAAAAAAb9ZKNG-jI_9kXYVDNUBQrCwIQz prod
                                                        -->
                                              <div id='html_element'></div>

                                              <script>         
                                              var recaptchaVal=false;                                   
                                              var onloadCallback = function() {
                                                    grecaptcha.render('html_element', {
                                                    'sitekey' : '6LeDvsAZAAAAAAb9ZKNG-jI_9kXYVDNUBQrCwIQz',
                                                    'callback' : correctCaptcha
                                                    });
                                                };
                                                var correctCaptcha = function(response) {
                                                    //alert(response);
                                                    recaptchaVal=true;
                                                };
                                                </script>

  



    <script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit" async defer></script>



                                        </div>
                                        <div class="columns"></div>
                                    </div>

                                    <div id="sending-form-5" class="sending-form" style="display: none;">Enviando...</div>
                                    <div id="response-message-back-5" class="panel-response-forms-contact"></div>
                                    <div class="row align-center">
                                        <input name="IDForm" type="hidden" value="5" />
                                        <input name="esCustomForm" type="hidden" value="si" />
                                        <input type="hidden" name="_token" value="IvCTS38L1DHagXSIojyn1SbqB9DBCqafS3sBWa1J" />
                                        <div class="columns small-4">
                                            <div class="button-wrapper"> 
                                                <button type="button" id="bt-submit-51"  onclick="gtSubmit()" class="" tracked="1" value="Submit"><span class="text metricas-enviarpqrs">Enviar</span> <span class="icon"></span></button>
                                                <span id="bt-submit-51-enviado" style="display:none"  class="text metricas-enviarpqrs">Procesando...</span>  
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            </div>
                        </div>
                </div>
            </section>
        </div>


      

                                                    


<script>

function letrasNUmeros(e){
    num=e.value; 
    // if(num!="" && num!=null){
    //   numcel=Number(num)+"";
    // }
	num = num.replace('1111', '1');
	num = num.replace('11111', '1');
	num = num.replace('2222', '2');
	num = num.replace('22222', '2');
	num = num.replace('3333', '3');
	num = num.replace('33333', '3');
	num = num.replace('4444', '4');
	num = num.replace('44444', '4');
	num = num.replace('5555', '5');
	num = num.replace('55555', '5');
	num = num.replace('6666', '6');
	num = num.replace('66666', '6');
	num = num.replace('7777', '7');
	num = num.replace('77777', '7');
	num = num.replace('8888', '8');
	num = num.replace('88888', '8');
	num = num.replace('9999', '9');
	num = num.replace('99999', '9');
	num = num.replace('0000', '0');
	num = num.replace('00000', '0');
    e.value=num.replace(/[^a-zA-Z0-9]/g, '');
  }


function validacion_tipodocu_select(v){
    if(v.value == 'CC'){
      $('#input_5_3').attr('onkeyup','soloNumeros(this),func_valid_CO1C(this,".errInput_5_3") ;');
      // $('#cedula').attr("maxlength", 10);
    }else if(v.value == 'CE'){
      $('#input_5_3').attr('onkeyup','soloNumeros(this),func_valid_CO1E(this,".errInput_5_3") ;');
      // $('#cedula').attr("maxlength", 7);
    }else if(v.value == 'PP'){
      $('#input_5_3').attr('onkeyup','func_valid_CO1P(this,".errInput_5_3"),letrasNUmeros(this);');
      // $('#cedula').attr("maxlength", 7);
    }else if(v.value == 'CD'){
      $('#input_5_3').attr('onkeyup','letrasNUmeros(this),func_valid_CO1D(this,".errInput_5_3");');
      // $('#cedula').attr("maxlength", 11);
    }else if(v.value == 'NI' ){
        $('#cedula').attr('onkeyup','func_valid_NI(this,".alert_valid_numdocu"),soloNumeros(this) ;');
      // $('#cedula').attr("maxlength", 11);
    }else if(v.value == 'RC'){
      $('#cedula').attr('onkeyup','func_valid_RC(this,".alert_valid_numdocu"),soloNumeros(this) ;');
      // $('#cedula').attr("maxlength", 11);
    }else if(v.value == 'AN'){
        
    }else{
      $('#input_5_3').removeAttr("maxlength");
    }
    $('#input_5_3').keyup();
  }




  function func_valid_NI(e,target_id){
    e.value=e.value;
    var valor = e.value;
    $('#errInput_5_3').html('');
    if(valor.length >= 3 && valor.length <= 10){
        $('#errInput_5_3').html(''); 
      document.getElementById("bt-submit-51").disabled = false;
    }else{
        $('#errInput_5_3').html('Verifique que el dato sea numérico de 3 a 10 caracteres'); 
        document.getElementById("bt-submit-51").disabled = true;
        document.getElementById('errInput_5_3').classList.add("error"); 
    }
  }
  
  function func_valid_RC(e,target_id){
    e.value=e.value;
    var valor = e.value;
    $('#errInput_5_3').html('');
    if(valor.length >= 10 && valor.length <= 11){
        $('#errInput_5_3').html(''); 
      document.getElementById("bt-submit-51").disabled = false;
    }else{
        $('#errInput_5_3').html('Verifique que el dato sea numérico de 10 a 11 caracteres'); 
        document.getElementById("bt-submit-51").disabled = true;
        document.getElementById('errInput_5_3').classList.add("error"); 
    }
  }



  function func_valid_CO1C(e,target_id){
    e.value=e.value;
    var valor = e.value;

    $('#errInput_5_3').empty(); 
    
    if(valor.length >= 3 && valor.length <= 10){
      $('#errInput_5_3').html('');
      document.getElementById("bt-submit-51").disabled = false;

	  let numDoc = valor * 1
	  if(numDoc > 2999999999){
		$('#errInput_5_3').html('Número no valido '); 
        document.getElementById("bt-submit-51").disabled = true;
        document.getElementById('errInput_5_3').classList.add("error"); 
	  }

    }else{
      $('#errInput_5_3').html('Verifique que el dato sea numérico de 3 a 10 caracteres'); 
      document.getElementById("bt-submit-51").disabled = true;
        document.getElementById('errInput_5_3').classList.add("error"); 
    }
  }
  function func_valid_CO1E(e,target_id){
    e.value=e.value;
    var valor = e.value;

    $('#errInput_5_3').html('');
    
    if(valor.length >= 3 && valor.length <= 7){
      $('#errInput_5_3').html('');
      document.getElementById("bt-submit-51").disabled = false;
    }else{
      $('#errInput_5_3').html('Verifique que el dato sea numérico de 3 a 7 caracteres'); 
      document.getElementById("bt-submit-51").disabled = true;
        document.getElementById('errInput_5_3').classList.add("error"); 
    }
  }
  function func_valid_CO1P(e,target_id){
    e.value=e.value;
    var valor = e.value;

    $('#errInput_5_3').html('');
    
    if(valor.length >= 3 && valor.length <= 17){
      $('#errInput_5_3').html('');
      document.getElementById("bt-submit-51").disabled = false;
    }else{
      $('#errInput_5_3').html('Verifique que el dato sea alfanumérico de 3 a 17 caracteres'); 
        document.getElementById('errInput_5_3').classList.add("error"); 
      document.getElementById("bt-submit-51").disabled = true;
    }
  }
  function func_valid_CO1D(e,target_id){
    e.value=e.value;
    var valor = e.value;

    $('#errInput_5_3').empty();
    
    if(valor.length >= 3 && valor.length <= 11){
      $('#errInput_5_3').html('');
      document.getElementById("bt-submit-51").disabled = false;
    }else{
      $('#errInput_5_3').html('Verifique que el dato sea alfanumérico de 3 a 11 caracteres'); 
        document.getElementById('errInput_5_3').classList.add("error"); 
      document.getElementById("bt-submit-51").disabled = true;
    }
  }   
  function letrasNUmeros(e){
    num=e.value; 
    // if(num!="" && num!=null){
    //   numcel=Number(num)+"";
    // }
	num = num.replace('1111', '1');
	num = num.replace('11111', '1');
	num = num.replace('2222', '2');
	num = num.replace('22222', '2');
	num = num.replace('3333', '3');
	num = num.replace('33333', '3');
	num = num.replace('4444', '4');
	num = num.replace('44444', '4');
	num = num.replace('5555', '5');
	num = num.replace('55555', '5');
	num = num.replace('6666', '6');
	num = num.replace('66666', '6');
	num = num.replace('7777', '7');
	num = num.replace('77777', '7');
	num = num.replace('8888', '8');
	num = num.replace('88888', '8');
	num = num.replace('9999', '9');
	num = num.replace('99999', '9');
	num = num.replace('0000', '0');
	num = num.replace('00000', '0');
    e.value=num.replace(/[^a-zA-Z0-9]/g, '');
  }


function soloNumeros(e) {
	num=e.value; 
	numcel="";
	num=num.replace(/[^0-9]/g, '')
	if(num!="" && num!=null){
		numcel=Number(num)+"";
	}
	e.value=numcel
}








function func_val_celular(){
	campo = document.getElementById('input_5_11');    
	numcel="";
	num=campo.value;
	num=num.replace(/[^0-9]/g, '')
	if(num!="" && num!=null){
		numcel=Number(num)+"";
		campo.value=numcel;
	}                                
	if((numcel<3000000000 || numcel>3999999999)  ){
        $('#errInput_5_11').html('Solo se permiten números en este campo<br>Debe iniciar siempre con el número 3<br>Solo puedes ingresar 10 digitos en este campo');
         document.getElementById("bt-submit-51").disabled = true;
        document.getElementById('errInput_5_11').classList.add("error"); 
        return false;
	}else{
        $('#errInput_5_11').html(''); 
      document.getElementById("bt-submit-51").disabled = false;
		return true;
	}	
}
  
 
var estadoValTel=false;
var estadoValTel2=false;


function func_val_tel(){
	campo = document.getElementById('input_5_14');    
	numcel="";
	num=campo.value;
	num=num.replace(/[^0-9]/g, '')
	if(num!="" && num!=null){
		numcel=Number(num)+"";
		campo.value=numcel;
	}                                
	if((numcel<6000000000 || numcel>6099999999)  ){
        $('#errInput_5_14').html('Solo se permiten números en este campo<br>Debe iniciar siempre con el número 60 <br>Solo puedes ingresar 10 digitos en este campo');
        document.getElementById("bt-submit-51").disabled = true;
        document.getElementById('errInput_5_14').classList.add("error");
        estadoValTel=false; 
	}else{
        $('#errInput_5_14').html(''); 
        document.getElementById("bt-submit-51").disabled = false;
        estadoValTel=true; 
	}	


	let campoTel2 = document.getElementById('input_5_12');    
    if(!estadoValTel2 && num.length>0){
        document.getElementById("bt-submit-51").disabled = true;
    }
    
}
       


function func_val_tel2(){
	campo = document.getElementById('input_5_12');    
	numcel="";
	num=campo.value;
	num=num.replace(/[^0-9]/g, '')
	if(num!="" && num!=null){
		numcel=Number(num)+"";
		campo.value=numcel;
	}                   
    let telAceptado = false;             
	if((numcel<6000000000 || numcel>6099999999)  ){
        $('#errInput_5_12').html('Solo se permiten números en este campo<br>Debe iniciar siempre con el número 60<br>Solo puedes ingresar 10 digitos en este campo');
        document.getElementById('errInput_5_12').classList.add("error");
        estadoValTel2=false;
        telAceptado = false;
	}else{
        $('#errInput_5_12').html(''); 
        estadoValTel2=true;
		telAceptado= true;
	}	

    if(!telAceptado && num.length>0){
        document.getElementById("bt-submit-51").disabled = true;
    }else{
        document.getElementById("bt-submit-51").disabled = false;
    }


    if(!estadoValTel){
        document.getElementById("bt-submit-51").disabled = true;
    }
    
}




</script>

        <script type="text/javascript" id="">

            var aceptarEnvioValidacion=true;


            const PrimerNombreCaracteres = (string) => {
                let out = '';
                const filtro = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                
                
                for (let i = 0; i < string.length; i++){
                    if (filtro.indexOf(string.charAt(i)) != -1){
                        out += string.charAt(i);
                        $('#errInput_5_5').html('');
                    }else{
                        $('#errInput_5_5').html('Solo se permiten letras en este campo');
                        aceptarEnvioValidacion=false;
                    }
                }
                return out;
            }

            const SegundoNombreCaracteres = (string) => {
                let out = '';
                const filtro = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                
                
                for (let i = 0; i < string.length; i++){
                    if (filtro.indexOf(string.charAt(i)) != -1){
                        out += string.charAt(i);
                        $('#errInput_5_6').html('');
                    }else{
                        $('#errInput_5_6').html('Solo se permiten letras en este campo');
                        aceptarEnvioValidacion=false;
                    }
                }
                return out;
            }

            const PrimerApellidoCaracteres = (string) => {
                let out = '';
                const filtro = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                
                
                for (let i = 0; i < string.length; i++){
                    if (filtro.indexOf(string.charAt(i)) != -1){
                        out += string.charAt(i);
                        $('#errInput_5_7').html('');
                    }else{
                        $('#errInput_5_7').html('Solo se permiten letras en este campo');
                        aceptarEnvioValidacion=false;
                    }
                }
                return out;
            }

            const SegundoApellidoCaracteres = (string) => {
                let out = '';
                const filtro = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                
                
                for (let i = 0; i < string.length; i++){
                    if (filtro.indexOf(string.charAt(i)) != -1){
                        out += string.charAt(i);
                        $('#errInput_5_8').html('');
                    }else{
                        $('#errInput_5_8').html('Solo se permiten letras en este campo');
                        aceptarEnvioValidacion=false;
                    }
                }
                return out;
            }

            

            const clearDocumentField = () => {
                const tipoDeDocumento = document.getElementById('input_2').value
                const nroDocumento = document.getElementById('input_5_3')
                const correoElectronico = document.getElementById('input_5_10')
                const nroContacto = document.getElementById('input_5_11')
                const medioDeRespuesta = document.getElementById('input_85')

                nroDocumento.value = '';

                if(tipoDeDocumento == 'AN'){
                    nroDocumento.required = false;
                    nroDocumento.ariaRequired = false;
                    nroDocumento.setAttribute('disabled','');
                    nroDocumento.classList.remove('error')
                    
                    correoElectronico.required = false;
                    correoElectronico.ariaRequired = false;
                    correoElectronico.setAttribute('disabled','');
                    correoElectronico.classList.remove('error')

                    nroContacto.required = false;
                    nroContacto.ariaRequired = false;
                    nroContacto.setAttribute('disabled', '');
                    nroContacto.classList.remove('error')

                    medioDeRespuesta.required = false;
                    medioDeRespuesta.ariaRequired = false;
                    medioDeRespuesta.setAttribute('disabled', '');
                    medioDeRespuesta.classList.remove('error')

                }else{
                    nroDocumento.required = true;
                    nroDocumento.removeAttribute('disabled');

                    correoElectronico.required = true;
                    correoElectronico.removeAttribute('disabled');

                    nroContacto.required = true;
                    nroContacto.removeAttribute('disabled');

                    medioDeRespuesta.required = true;
                    medioDeRespuesta.removeAttribute('disabled');
                }
            }

            const cargaCiudades = (event) => {
                
                fetch('./colombia.json')
                    .then(resp => resp.json())
                    .then(data => {
                        const json = JSON.stringify(data)
                        const array = JSON.parse(json)
                        Object.keys(array).length
                        
                        const departamento = $('#input_17').val()
                        let option = ''
                        
                        for (let i = 0; i < array.length; i++) {
                            if(array[i]['id'] == departamento){
                                
                                for (let j = 0; j < array[i]['ciudades'].length; j++) {
                                    option += '<option value="'+ array[i]['ciudades'][j] +'">'+ array[i]['ciudades'][j] +'</option>'
                                }
                            }
                            
                        }

                        $('#input_18').html('<option value="">Selecciona una opción</option>' + option)

                    })
                
            }
  

            const telOficina = (string) => {
                let out = ''
                let charInit = ''
                const numerico = '0123456789'
                
                for (let i = 0; i < string.length; i++){
                    if (numerico.indexOf(string.charAt(i)) != -1 && string.charAt(0) == 6 && string.charAt(1) == 0){
                        out += string.charAt(i);
                        $('#errInput_5_12').html('');
                    }else{
                        $('#errInput_5_12').html('Solo se permiten números en este campo<br>Debe iniciar siempre con el número 60<br>Solo puedes ingresar 10 digitos en este campo');
                        aceptarEnvioValidacion=false;
                    }
                        
                }
                return out.substr(0,10);
            }

            const extOficina = (string) => {
                let out = ''
                let charInit = ''
                const numerico = '0123456789'
                
                for (let i = 0; i < string.length; i++){
                    if (numerico.indexOf(string.charAt(i)) != -1){
                        out += string.charAt(i);
                        $('#errInput_5_13').html('');
                    }else{
                        $('#errInput_5_13').html('Solo se permiten números en este campo<br>Ingresa como máximo 7 digitos');
                        aceptarEnvioValidacion=false;
                    }
                }
                return out.substr(0,7);
            }

            const DireccionCaracteres = (string) => {
                let out = '';
                const filtro = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-# 0123456789';
                
                
                for (let i = 0; i < string.length; i++){
                    if (filtro.indexOf(string.charAt(i)) != -1){
                        out += string.charAt(i);
                        $('#errInput_5_9').html('');
                    }else{
                        $('#errInput_5_9').html('Solo se permiten letras, numeros, -, #, en este campo');
                        aceptarEnvioValidacion=false;
                    }
                }
                return out;
            }

            function funcMedioDeRespuesta() {
                let metodoDeRespuesta = document.getElementById('input_85').value
                let DivDireccionCorrespondencia = document.getElementById('input_84')
                let DivCorreoRespuesta = document.getElementById('input_83')

                let direccionCorrespondencia1 = document.getElementById('input_81')
                let direccionCorrespondencia2 = document.getElementById('input_80')
                let direccionCorrespondencia3 = document.getElementById('input_79')
                let direccionCorrespondencia4 = document.getElementById('input_78')
                
                

                if(metodoDeRespuesta == 'correspondencia'){
                    DivDireccionCorrespondencia.style.display = 'block'
                    DivCorreoRespuesta.style.display = 'none'
                    
                    document.getElementById('input_82').required = false

                    direccionCorrespondencia1.required = true
                    direccionCorrespondencia2.required = true
                    direccionCorrespondencia3.required = true
                    direccionCorrespondencia4.required = true

                }else if(metodoDeRespuesta == 'correo'){
                    DivDireccionCorrespondencia.style.display = 'none'
                    DivCorreoRespuesta.style.display = 'block'
                    //correo required
                    document.getElementById('input_82').required = true
                    //dir fisica no required
                    direccionCorrespondencia1.required = false
                    direccionCorrespondencia2.required = false
                    direccionCorrespondencia3.required = false
                    direccionCorrespondencia4.required = false

                }else{
                    DivDireccionCorrespondencia.style.display = 'none'
                    DivCorreoRespuesta.style.display = 'none'
                    document.getElementById('input_82').required = false
                }
            }









            function validarCamposComplejos() { 

                aceptarEnvioValidacion=true;
                let ip055=document.getElementById("input_5_5");
                ip055.value=PrimerNombreCaracteres(ip055.value);
                
                let ip056=document.getElementById("input_5_6");
                ip056.value=SegundoNombreCaracteres(ip056.value);
                
                let ip057=document.getElementById("input_5_7");
                ip057.value=PrimerApellidoCaracteres(ip057.value);
                
                let ip058=document.getElementById("input_5_8");
                ip058.value=SegundoApellidoCaracteres(ip058.value);
                
                let ip0513=document.getElementById("input_5_13");
                ip0513.value=extOficina(ip0513.value);
                
                let ip059=document.getElementById("input_5_9");
                ip059.value=DireccionCaracteres(ip059.value);
            }

 


            function gtSubmit() {

              

                let elementsbody = document.querySelectorAll( 'body *' );
                for (var i2 = 0; i2 < elementsbody.length; i2++) {

                    try {
                        element33 = document.getElementById(elementsbody[i2].id);
                        element33.classList.remove("errorNew");
                    } catch (e) {}
                }

                let contactForm = document.getElementById("formulario-integración-servicio-5-5");
                let item = contactForm.querySelectorAll(":invalid"); 
                let noEnviar = true;
                document.getElementById('input_66-error').style.display="none";

                for (var i = 0; i < item.length; i++) {
                    try {
                        element = document.getElementById(item[i].id);
                        if (item[i].id != "input_4" && item[i].id != "input_5_6" && item[i].id != "input_5_8" && item[i].id != "input_5_12" && item[i].id != "input_5_13" && item[i].id != "input_5_14" && item[i].id != "input_5_25") {
                        
                            console.log(item[i].name + ": " + item[i].validity.valid);
                            
                            element.classList.add("errorNew");
                            noEnviar = false;


                            if (item[i].id == "input_66"){
                                document.getElementById('input_66-error').style.display="block"; 
                                document.getElementById('input_66-error').classList.add("error");

                            }


                            //return false;
                        } 
                    } catch (e) {}
                }

                validarCamposComplejos() ;


                if (noEnviar) {
                    var event = 'ga_event_pqrssolicitud';
                    var category = 'PQRS';
                    var action = 'Clic-boton';
                    var label = 'Crear solicitud';
                    var Seccion = 'Solicitudes, felicitaciones, reclamos y sugerencias';
                    var numero_documento = $('#formulario-integración-servicio-5-5 #input_5_3').val();

                    tagFormulario(event,category,action,label,Seccion, numero_documento);
                    
                    document.getElementById("bt-submit-51").style.display="none";
                    document.getElementById('bt-submit-51-enviado').style.display="block"; 

                    if( aceptarEnvioValidacion== false || !recaptchaVal){
                        noEnviar = false;
                        return false;
                    }else{
                        document.getElementById("formulario-integración-servicio-5-5").submit();
                        return true;
                    }
                    
                    

                } else{

                    return false;
                }
            }
        </script>

        

        <div id="wrap-map-directions" style="display: none;" data-msgnoresults="No se pudo determinar una ruta con el medio indicado." data-msgyhere="Usted esta aquí">
            <div class="wrap-map">
                <div id="messages-map-directions"></div>
                <span id="cl-map-directions">x</span>
                <div id="panel-map-directions"></div>
                <div class="items-options-wrap">
                    <ul>
                        <li>
                            <label>
                                <input type="radio" name="mp_directions" value="driving" />
                                Vehículo
                            </label>
                        </li>
                        <li>
                            <label>
                                <input type="radio" name="mp_directions" value="transit" />
                                Transporte público
                            </label>
                        </li>
                        <li>
                            <label>
                                <input type="radio" name="mp_directions" value="walking" />
                                Caminando
                            </label>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        
        <script src="./index_files/jquery.js"></script>
        <script src="./index_files/what-input.js"></script>
        <script src="./index_files/foundation.js"></script>
        <script src="./index_files/motion-ui.js"></script>
        <script src="./index_files/foundation-datepicker.js"></script>
        <script src="./index_files/jquery.fancybox.js"></script>
        <script src="./index_files/jquery.validate.min.js"></script>
        <script src="./index_files/jquery.validate.file.js"></script>
        <script src="./index_files/additional-methods.min.js"></script>
        <script src="./index_files/js.cookie.js"></script>
        <script src="./index_files/jquery.panorama_viewer.js"></script> 
        
        <script src="./index_files/tracking.min.js"></script>
       

    
    <!-- FOOTER -->
<div class="row-fluid-wrapper row-depth-1 row-number-15">
            <div class="row-fluid">
                <div class="span12 widget-span widget-type-custom_widget" data-widget-type="custom_widget" data-x="0" data-w="12">
                    <div id="hs_cos_wrapper_module_166016610739681" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module" data-hs-cos-general-type="widget" data-hs-cos-type="module">
                        <div class="hu42a-help hu42a-help-container" id="">
                            <div class="content square-wrapper">
                                <h2 class="hu42a-help-title">¿Necesitas ayuda?</h2>
                                <h3 class="hu42a-help-title">¿Necesitas ayuda?</h3>
                                <div class="content-item item-total-3">
                                    <div class="hu42a-help-col-wraper">
                                        <div class="item-wraper">
                                            <div class="item">
                                                <div class="img">
                                                    <img src="https://7212050.fs1.hubspotusercontent-na1.net/hubfs/7212050/Sitio%20.COM/new-content/iconos/icono-ingresa-al-portal-negro.svg" alt="icono-ingresa-al-portal-negro" />
                                                </div>
                                                <div class="titulo">
                                                    <h3>Consúltanos</h3>
                                                </div>
                                            </div>
                                            <div class="text">
                                                <p>En todos los <a href="https://www.colsubsidio.com/consultanos" rel="noopener" data-category="¿Necesitas ayuda?">canales a disposición</a></p>
                                                <p>&nbsp;</p>
                                                <p>
                                                    Escribiendo al correo de notificaciones judiciales:
                                                    <a href="mailto:servicioalcliente@colsubsidio.com" rel="noopener" data-category="¿Necesitas ayuda?">servicioalcliente@colsubsidio.com</a>
                                                </p>
                                                <p>&nbsp;</p>
                                                <p><a href="https://www.colsubsidio.com/nosotros/gobierno-corporativo" rel="noopener" data-category="¿Necesitas ayuda?">Políticas y cumplimiento legal</a></p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="hu42a-help-col-wraper">
                                        <div class="item-wraper">
                                            <div class="item">
                                                <div class="img">
                                                    <img src="https://7212050.fs1.hubspotusercontent-na1.net/hubfs/7212050/Piscilago/iconos/Telefono2.svg" alt="Telefono" />
                                                </div>
                                                <div class="titulo">
                                                    <h3>Llámanos</h3>
                                                </div>
                                            </div>
                                            <div class="text">
                                                <p>Al teléfono gratuito de servicio al&nbsp;ciudadano:&nbsp;</p>
                                                <p>&nbsp;</p>
                                                <p>
                                                    En Bogotá:
                                                    <a href="tel:6017457900" rel="noopener" target="_blank" data-category="¿Necesitas ayuda?">
                                                        +<span data-contrast="none" xml:lang="ES-CO" lang="ES-CO"><span data-ccp-charstyle="Hyperlink">57 601 745 79 00</span></span>
                                                    </a>
                                                </p>
                                                <p>Línea Nacional: <a href="tel:018000947900" rel="noopener" data-category="¿Necesitas ayuda?">01 8000 947 900</a></p>
                                                <p>
                                                    <span data-contrast="none" xml:lang="ES-CO" lang="ES-CO"><span data-ccp-parastyle="Normal (Web)">Sede Administrativa</span></span>:
                                                    <a href="tel:6017420100" rel="noopener" data-category="¿Necesitas ayuda?">+</a>
                                                    <a href="tel:6017420100" target="_blank" rel="noreferrer noopener" data-category="¿Necesitas ayuda?">
                                                        <span data-contrast="none" xml:lang="ES-CO" lang="ES-CO"><span data-ccp-charstyle="Hyperlink">57 601 742 01 00</span></span>
                                                    </a>
                                                </p>
                                                <p>&nbsp;</p>
                                                <p>Línea ética:&nbsp;<a href="tel:018000975822" rel="noopener" data-category="¿Necesitas ayuda?">01 8000975822</a></p>
                                                <p>
                                                    Conoce todas nuestras
                                                    <a href="https://www.colsubsidio.com/consultanos/centros-de-servicio#contact-center" rel="noopener" data-category="¿Necesitas ayuda?"> líneas de&nbsp;atención telefónica</a>
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="hu42a-help-col-wraper">
                                        <div class="item-wraper">
                                            <div class="item">
                                                <div class="img">
                                                    <img src="https://7212050.fs1.hubspotusercontent-na1.net/hubfs/7212050/Sitio%20.COM/new-content/iconos/ubicacion-simple-monotono.svg" alt="ubicacion-simple-monotono" />
                                                </div>
                                                <div class="titulo">
                                                    <h3>Visítanos</h3>
                                                </div>
                                            </div>
                                            <div class="text">
                                                <p>
                                                    <span data-scheme-color="@001F5B,1," data-usefontface="true" data-contrast="none">En nuestra sede principal: Calle 26 N.º&nbsp;</span>
                                                    <span data-scheme-color="@001F5B,1," data-usefontface="true" data-contrast="none">25 - 50 Bogotá D.C.</span><span></span>
                                                </p>
                                                <p>&nbsp;</p>
                                                <p>
                                                    <span data-usefontface="false" data-contrast="none">Ubica todas <a href="https://www.colsubsidio.com/sedes" rel="noopener" data-category="¿Necesitas ayuda?">nuestras sedes</a></span>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end widget-span -->
            </div>
            <!--end row-->
        </div>
        <!-- FOOTER -->
        <!--end body wrapper -->
        <div class="footer-container-wrapper">
            <div class="footer-container container-fluid">
                <div class="row-fluid-wrapper row-depth-1 row-number-1">
                    <div class="row-fluid">
                        <div class="span12 widget-span widget-type-cell" data-widget-type="cell" data-x="0" data-w="12">
                            <div class="row-fluid-wrapper row-depth-1 row-number-2">
                                <div class="row-fluid">
                                    <div class="span12 widget-span widget-type-global_group" data-widget-type="global_group" data-x="0" data-w="12">
                                        <div class="" data-global-widget-path="generated_global_groups/55350067337.html">
                                            <div class="row-fluid-wrapper row-depth-1 row-number-1">
                                                <div class="row-fluid">
                                                    <div class="span12 widget-span widget-type-custom_widget separador-linea-footer" data-widget-type="custom_widget" data-x="0" data-w="12">
                                                        <div id="hs_cos_wrapper_module_536785764" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module" data-hs-cos-general-type="widget" data-hs-cos-type="module">
                                                            <div class="container-separador" style="justify-content: center; margin: 30px 0px; height: 1px !important;">
                                                                <hr class="separador-linea" style="border-width: 1px; width: 100%; opacity: 0%; margin: 0;" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--end widget-span -->
                                                </div>
                                                <!--end row-->
                                            </div>
                                            <!--end row-wrapper -->

                                            <div class="row-fluid-wrapper row-depth-1 row-number-2">
                                                <div class="row-fluid">
                                                    <div class="span12 widget-span widget-type-custom_widget" data-widget-type="custom_widget" data-x="0" data-w="12">
                                                        <div id="hs_cos_wrapper_module_574745543" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module" data-hs-cos-general-type="widget" data-hs-cos-type="module">
                                                            <div class="imagen">
                                                                <div class="grafico">
                                                                    <div class="grafico-fondo grafico-desktop-personajes">
                                                                        <img src="https://7212050.fs1.hubspotusercontent-na1.net/hubfs/7212050/banner-images/personajes.svg" alt="personajes" loading="lazy" />
                                                                    </div>
                                                                    <div class="grafico-fondo grafico-desktop">
                                                                        <img src="https://7212050.fs1.hubspotusercontent-na1.net/hubfs/7212050/banner-images/fondonuevo.svg" alt="fondonuevo" loading="lazy" />
                                                                    </div>
                                                                    <div class="grafico-fondo grafico-tablet">
                                                                        <img src="https://7212050.fs1.hubspotusercontent-na1.net/hubfs/7212050/banner-images/fondo-tablet.svg" alt="fondo-tablet" loading="lazy" />
                                                                    </div>
                                                                    <div class="grafico-fondo grafico-mobile">
                                                                        <img src="https://7212050.fs1.hubspotusercontent-na1.net/hubfs/7212050/banner-images/fondo-mobile.svg" alt="fondo-mobile" loading="lazy" />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--end widget-span -->
                                                </div>
                                                <!--end row-->
                                            </div>
                                            <!--end row-wrapper -->

                                            <div class="row-fluid-wrapper row-depth-1 row-number-3">
                                                <div class="row-fluid">
                                                    <div class="span12 widget-span widget-type-custom_widget" data-widget-type="custom_widget" data-x="0" data-w="12">
                                                        <div id="hs_cos_wrapper_module_412659844" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module" data-hs-cos-general-type="widget" data-hs-cos-type="module">
                                                            <div class="about" id="">
                                                                <div class="content">
                                                                    <h2>Conócenos</h2>
                                                                    <div class="nav_about">
                                                                        <a
                                                                            href="https://www.colsubsidio.com/nosotros"
                                                                            class="metricas-conocenos"
                                                                            data-nombre="Nuestra organización"
                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                        >
                                                                            Nuestra organización
                                                                        </a>

                                                                        <a
                                                                            href="https://ayuda.colsubsidio.com/"
                                                                            target="_blank"
                                                                            rel="noopener"
                                                                            class="metricas-conocenos"
                                                                            data-nombre="Centro de ayuda "
                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                        >
                                                                            Centro de ayuda
                                                                        </a>

                                                                        <a
                                                                            href="https://www.colsubsidio.com/proveedores"
                                                                            class="metricas-conocenos"
                                                                            data-nombre="Proveedores"
                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                        >
                                                                            Proveedores
                                                                        </a>

                                                                        <a
                                                                            href="https://www.colsubsidio.com/medios-de-pago"
                                                                            class="metricas-conocenos"
                                                                            data-nombre="Medios de pago"
                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                        >
                                                                            Medios de pago
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--end widget-span -->
                                                </div>
                                                <!--end row-->
                                            </div>
                                            <!--end row-wrapper -->

                                            <div class="row-fluid-wrapper row-depth-1 row-number-4">
                                                <div class="row-fluid">
                                                    <div class="span12 widget-span widget-type-custom_widget" data-widget-type="custom_widget" data-x="0" data-w="12">
                                                        <div id="hs_cos_wrapper_module_433908075" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module" data-hs-cos-general-type="widget" data-hs-cos-type="module">
                                                            <div class="follow" id="">
                                                                <div class="up">
                                                                    <img src="https://www.colsubsidio.com/hubfs/Sitio%20.COM/new-content/iconos/up-icon.svg" alt="Ir Arriba" loading="lazy" width="54" height="54" />
                                                                </div>
                                                                <div class="content wrapper">
                                                                    <h2>Síguenos</h2>
                                                                    <div class="items">
                                                                        <a
                                                                            class="metricas-redes"
                                                                            href="https://twitter.com/Colsubsidio_Ofi"
                                                                            target="_blank"
                                                                            rel="noopener"
                                                                            data-red="Twitter"
                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                        >
                                                                            <img src="https://7212050.fs1.hubspotusercontent-na1.net/hubfs/7212050/Redes%20sociales/Twitter.svg" alt="" loading="lazy" width="18" height="18" />
                                                                            <span>Twitter</span>
                                                                        </a>

                                                                        <a
                                                                            class="metricas-redes"
                                                                            href="https://www.facebook.com/Colsubsidio/"
                                                                            target="_blank"
                                                                            rel="noopener"
                                                                            data-red="Facebook"
                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                        >
                                                                            <img src="https://7212050.fs1.hubspotusercontent-na1.net/hubfs/7212050/Redes%20sociales/Facebook.svg" alt="" loading="lazy" width="18" height="18" />
                                                                            <span>Facebook</span>
                                                                        </a>

                                                                        <a
                                                                            class="metricas-redes"
                                                                            href="https://www.linkedin.com/company/colsubsidio/"
                                                                            target="_blank"
                                                                            rel="noopener"
                                                                            data-red="LinkedIn"
                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                        >
                                                                            <img src="https://7212050.fs1.hubspotusercontent-na1.net/hubfs/7212050/Redes%20sociales/LinkedIN.svg" alt="" loading="lazy" width="18" height="18" />
                                                                            <span>LinkedIn</span>
                                                                        </a>

                                                                        <a
                                                                            class="metricas-redes"
                                                                            href="https://www.youtube.com/user/Colsubsidio01"
                                                                            target="_blank"
                                                                            rel="noopener"
                                                                            data-red="YouTube"
                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                        >
                                                                            <img src="https://7212050.fs1.hubspotusercontent-na1.net/hubfs/7212050/Redes%20sociales/Youtube.svg" alt="" loading="lazy" width="18" height="18" />
                                                                            <span>YouTube</span>
                                                                        </a>

                                                                        <!--        -->

                                                                        <a href="https://ssf.gov.co" class="logo-supersubsidio" target="_blank" rel="nofollow noopener">
                                                                            <img
                                                                                src="https://7212050.fs1.hubspotusercontent-na1.net/hubfs/7212050/Sitio%20.COM/new-content/Logo-v-SuperSubsidio.svg"
                                                                                alt="Logo Vigilado SuperSuvsidio - Superintendente del Subsidio Familiar "
                                                                                loading="lazy"
                                                                            />
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--end widget-span -->
                                                </div>
                                                <!--end row-->
                                            </div>
                                            <!--end row-wrapper -->

                                            <div class="row-fluid-wrapper row-depth-1 row-number-5">
                                                <div class="row-fluid">
                                                    <div class="span12 widget-span widget-type-custom_widget" data-widget-type="custom_widget" data-x="0" data-w="12">
                                                        <div id="hs_cos_wrapper_module_813306413" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module" data-hs-cos-general-type="widget" data-hs-cos-type="module">
                                                            <div class="footer_link" id="">
                                                                <div class="content wrapper">
                                                                    <div class="left">
                                                                        <a
                                                                            href="https://www.colsubsidio.com/tratamiento-de-datos"
                                                                            class="metricas-enlaces"
                                                                            data-nombre="Tratamiento de datos personales"
                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                        >
                                                                            Tratamiento de datos personales
                                                                        </a>

                                                                        <a
                                                                            href="https://www.colsubsidio.com/pqr/"
                                                                            target="_blank"
                                                                            rel="noopener"
                                                                            class="metricas-enlaces"
                                                                            data-nombre="PQRS"
                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                        >
                                                                            PQRS
                                                                        </a>

                                                                        <a
                                                                            href="https://www.colsubsidio.com/transparencia-y-acceso-a-la-informacion"
                                                                            class="metricas-enlaces"
                                                                            data-nombre="Transparencia"
                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                        >
                                                                            Transparencia
                                                                        </a>

                                                                        <a
                                                                            href="https://www.colsubsidio.com/compromisos"
                                                                            class="metricas-enlaces"
                                                                            data-nombre="Compromiso con usuarios"
                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                        >
                                                                            Compromiso con usuarios
                                                                        </a>

                                                                        <a
                                                                            href="https://www.colsubsidio.com/mapa-del-sitio"
                                                                            class="metricas-enlaces"
                                                                            data-nombre="Mapa del sitio"
                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                        >
                                                                            Mapa del sitio
                                                                        </a>

                                                                        <a
                                                                            href="https://www.colsubsidio.com/hubfs/documentos/colsubsidio/terminos-y-condiciones-portal-web-colsubsidio.pdf"
                                                                            class="metricas-enlaces"
                                                                            data-nombre="Términos y condiciones&nbsp;"
                                                                            data-seccion="Colsubsidio | Caja Colombiana de Subsidio Familiar"
                                                                        >
                                                                            Términos y condiciones&nbsp;
                                                                        </a>
                                                                    </div>
                                                                    <div class="right">Todos los derechos reservados © Colsubsidio <span id="copyDate">2022</span></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--end widget-span -->
                                                </div>
                                                <!--end row-->
                                            </div>
                                            <!--end row-wrapper -->
                                        </div>
                                    </div>
                                    <!--end widget-span -->
                                </div>
                                <!--end row-->
                            </div>
                            <!--end row-wrapper -->
                        </div>
                        <!--end widget-span -->
                    </div>
                    <!--end row-->
                </div>
                <!--end row-wrapper -->
            </div>
            <!--end footer -->
        </div>

<!-- FIN FOOTER -->

<style>
    .follow .up img {
        height: 54px;
    }
</style>

<script src="https://cdn2.hubspot.net/hub/7212050/hub_generated/template_assets/41196035292/1639169688996/Colsubsidio_2021/sources/js/main.min.js?ver=2"></script>
<script src="https://cdn2.hubspot.net/hub/7212050/hub_generated/module_assets/41196033481/1639169281672/module_41196033481_HU02_Header_Empresas.min.js"></script>

<style>
    #hs_cos_wrapper_module_817564709 a:hover,
    #hs_cos_wrapper_module_681084157 a:hover,
    #hs_cos_wrapper_module_448794365 a:hover {
        text-decoration: underline !important;
    }
</style>

<script src="./js/taggeo.js?v=1845057815"></script>
    
<script>

$(document).ready(function(){
$('.up').click(function(){
$('body, html').animate({
    scrollTop: '0px'
}, 300);
});

$(window).scroll(function(){
if( $(this).scrollTop() > 0 ){
    $('.up').slideDown(300);
} else {
    $('.up').slideUp(300);
}
});

});


</script>

    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/bootstrap.bundle.js"></script>

   

    <style>
    .errorNew {
        border: 1px solid red  !important;
    }  
     </body>
</html>