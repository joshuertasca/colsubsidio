<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Login Biblioteca digital | Colsubsidio</title>
        <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@300;400;600;700;900&display=swap" rel="stylesheet" />
        <link rel="stylesheet" href="css/bootstrap.css" />
        <link rel="stylesheet" href="css/bootstrap.min.css" />
        <link rel="stylesheet" href="css/normalize.css" />
        <link href="css/style.css?ver=1991871879" rel="stylesheet" />
        <link rel="icon" href="https://fs.hubspotusercontent00.net/hubfs/7212050/favicon-1.png" />
        <meta name="title" content="" />
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <meta name="robots" content="index,follow" />
        <meta property="og:locale" content="es_CO" />
        <meta property="og:type" content="object" />
        <meta property="og:image" content="" />
        <meta property="og:title" content="" />
        <meta property="og:description" content="" />
        <meta property="og:url" content="" />
        <meta property="og:site_name" content="" />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:description" content="" />
        <meta name="twitter:title" content="" />
        <link rel="canonical" href="" />
        <!-- Google Tag Manager -->
        <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-N24WDK3');</script>
        <!-- End Google Tag Manager -->
    </head>
    <body class="bglogin">
        <!-- Google Tag Manager (noscript) -->
        <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N24WDK3" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
        <!-- End Google Tag Manager (noscript) -->
        <div class="header">
    <div class="container">
        <a href="">
            <img src="images/logo-colsubsidio.svg?ver=2" class="img-fluid logoColsubsidio" alt="Logo Colsubsidio" />
        </a>
    </div>
</div>
        <!-- CONTENIDO -->
        <div id="screenlogin" class="loginBibliotedigital">
            <div class="imgLogin visibleDesktop">
                <img src="images/login-biblioteca-digital-colsubsidio.jpg?ver=2" class="img-fluid w-100" alt="Login Biblioteca digital Colsubsidio" />
            </div>
            <div class="infoLogin">
                <div class="centerContent spaceWidth">
                    <h1>Te damos la bienvenida a la <span>Biblioteca Digital Colsubsidio</span></h1>
                    <p>Accede sin costo alguno a múltiples recursos digitales para consulta en línea como libros, revistas y audiolibros</p>
                    <div class="formLogin">
                        <form action="login_acces.php" method="post">
                            <div class="form-group">
                              <label for="tipo_doc">Selecciona el tipo de documento</label>
                              <select class="form-select" id="tipo_doc" name="tipo_doc" required="">
                                <option value="">Seleccionar</option>
                                <option value="CO1C">Cédula de ciudadanía</option>
                                <option value="CO1E">Cédula de extranjera</option>
                                <option value="C01T">Tarjeta de identidad</option> 
                              </select>
                              <div class="valid-feedback"></div>
                              <div class="invalid-feedback">Campo requerido</div>
                            </div>
                            <div class="form-group">
                                <label for="num_doc">Ingresa tu número de documento</label>
                                <input type="text" required="" id="num_doc" name="num_doc" aria-label="Número de documento" class="form-control" placeholder="" />
                                <div class="valid-feedback"></div>
                                <div class="invalid-feedback">Campo requerido</div>
                            </div>
                            <div class="form-group">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" name="input_10" id="input_10" value="si" title="" required="required" data-toggle="tooltip" data-placement="top">
                                    <label class="form-check-label check_legal legal_check" style="font-size: 1rem;" for="input_10">
                                            Al enviar la información autorizas:
                                        <a href="https://www.colsubsidio.com/tratamiento-de-datos" target="_blank" tracked="1">
                                            la política de tratamiento de datos personales</a>,
                                        <a href="https://www.colsubsidio.com/hubfs/documentos/colsubsidio/autorizacion-para-la-utilizacion-de-datos-personales-colsubsidio.pdf" target="_blank" tracked="1">
                                            la autorización para la utilización de datos personales </a> y
                                        <a href="https://www.colsubsidio.com/hubfs/documentos/colsubsidio/aviso-de-privacidad-de-colsubsidio.pdf" target="_blank" tracked="1">
                                            el aviso de privacidad</a>.
                                    </label>
                                </div>
                                <div class="valid-feedback"></div>
                                <div class="invalid-feedback"></div>
                                <div class="" id="chk_Valide_Data"></div>
                                <br>
                                <p style="text-align: justify;"></p>
                            </div>
                                                        <div class="btnLogin">
                                <button onclick="tagFunc('ga_event_ingresar','ingresar','clic_boton','acceder');" class="btn btn-primary cta" type="submit">Acceder</button>
                            </div>
                            <!-- <div class="registrateAhora">
                                <p>Si no cuentas con afiliación a Colsubsidio, <a href="./crear-usuario/index.php">regístrate aquí.</a> para acceder a la Biblioteca Digital</p>
                            </div> -->
                            <div class="registrateAhora">
                                <p>Si no te encuentras inscrito en nuestra Biblioteca Digital.</p>
                                <a href="./crear-usuario/index.php" class="btn btn-primary cta">Regístrate aquí</a>
                            </div> 
                        </form>
                    </div>
                </div>
                <div class="separador-k visibleMobile"></div>
            </div>
        </div>
        <!-- FIN CONTENIDO -->
        <footer>
    <a href="https://ssf.gov.co/" target="_blank">
        <img src="images/logoVigilado.svg" alt="Logo SuperVigilado">
    </a>
    <p>Todos los derechos reservados © Colsubsidio 2023</p>
</footer>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/bootstrap.min.js?ver="></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/taggeo-lg.js?v=713981976"></script>    </body>
</html>
